package com.vm.shadowsocks.ui;

import android.content.Context;
import android.util.Log;

import com.vm.shadowsocks.model.PreferenceHelper;
import com.vm.shadowsocks.model.SsServer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Luis on 11/14/17.
 *
 */

public class ConnectModel {
    static final int STATE_DISCONNECTED = 0;
    static final int STATE_CONNECTING = 1;
    static final int STATE_CONNECTED = 2;
    static final String KEY_CONNECTED_TIME = "key_connected_time";

    int mState;
    SsServer mServer;

    public ConnectModel(SsServer server) {
        mServer = server;
    }

    void setTime(Context context) {
        PreferenceHelper.get(context).setLong(KEY_CONNECTED_TIME, System.currentTimeMillis());
    }

    long getDeltaTime(Context context) {
        long sp = PreferenceHelper.get(context).getLong(KEY_CONNECTED_TIME, 0);
        long res = System.currentTimeMillis() - sp;
        return res;
    }

    String getDeltaTimeText(Context context) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+0:00"));
        Date delta = new Date(getDeltaTime(context));
        return sdf.format(delta);
    }
}
