package com.vm.shadowsocks.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.monkey.vpn.R;
import com.vm.shadowsocks.firebase.remoteconfig.RemoteConfigHelper;

import java.util.ArrayList;
import java.util.List;

import util.android.content.ContextUtil;

/**
 * Created by Luis
 * on 11/21/17.
 */

public class HomeActivityDrawerView extends RelativeLayout {

    private Activity mActivity;
    private View mHead;
    private View mName;
    private View mBody;
    private RecyclerView mRecycler;
    private LinearLayoutManager mLayoutManager;
    private RecyclerAdapter mRecyclerAdapter;

    public HomeActivityDrawerView(Context context) {
        super(context);
        mActivity = (Activity) context;
    }

    public HomeActivityDrawerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mActivity = (Activity) context;
    }

    public HomeActivityDrawerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mActivity = (Activity) context;
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        init();
    }

    private Activity getActivity() {
        return mActivity;
    }

    private HomeActivity getHomeActivity() {
        return (HomeActivity) getActivity();
    }

    private void init() {
        mHead = findViewById(R.id.head);
        mName = findViewById(R.id.name);
        mBody = findViewById(R.id.body);
        mRecycler = findViewById(R.id.recycler);

        mLayoutManager = new LinearLayoutManager(getContext());
        mRecycler.setLayoutManager(mLayoutManager);

        mRecyclerAdapter = new RecyclerAdapter();
        mRecycler.setAdapter(mRecyclerAdapter);
    }

    private class RecyclerItem {
        CharSequence mText;
        int mDrawableRes;

        RecyclerItem(CharSequence text, int drawableRes) {
            mText = text;
            mDrawableRes = drawableRes;
        }
    }

    private class RecyclerViewHolder extends RecyclerView.ViewHolder {
        private ImageView mIcon;
        private TextView mName;

        public RecyclerViewHolder(View itemView) {
            super(itemView);
            mIcon = itemView.findViewById(R.id.icon);
            mName = itemView.findViewById(R.id.name);
        }

        public void bind(OnClickListener click) {
            itemView.setOnClickListener(click);
        }
    }

    private class RecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private List<RecyclerItem> mItems;

        RecyclerAdapter() {
            mItems = new ArrayList<>();
            mItems.add(new RecyclerItem(getContext().getText(R.string.home_activity_menu_server), R.drawable.ic_setting));
            mItems.add(new RecyclerItem(getContext().getText(R.string.home_activity_menu_feedback), R.drawable.ic_setting_feedback));

            if (RemoteConfigHelper.get().isMenuSpeedTestEnabled()) {
                mItems.add(new RecyclerItem(getContext().getText(R.string.home_activity_menu_speedtest), R.drawable.ic_setting_faq));
            }

            mItems.add(new RecyclerItem(getContext().getText(R.string.home_activity_menu_about), R.drawable.ic_about));
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(getContext()).inflate(R.layout.home_activity_drawer_item, null);;
            return new RecyclerViewHolder(v);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
            if (holder instanceof RecyclerViewHolder) {
                RecyclerItem item = mItems.get(position);

                RecyclerViewHolder rvh = (RecyclerViewHolder) holder;
                rvh.mName.setText(item.mText);
                rvh.mIcon.setImageResource(item.mDrawableRes);
                rvh.itemView.setTag(position);
                rvh.bind(mOnClick);
            }
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }
    }

    private OnClickListener mOnClick = new OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getTag() instanceof Integer) {
                int position = (int) v.getTag();
                if (position == 0) {
                    Intent i = new Intent(getContext(), ServersActivity.class);
                    getActivity().startActivityForResult(i, HomeActivity.REQUEST_CODE_SERVER_CHANGE);

                } else if (position == 1) {
                    ContextUtil.sendFeedback(getContext(), "betterappteam@gmail.com");

                } else if (position == 2) {
                    WebViewActivity.loadUrl(getContext(), getContext().getString(R.string.home_activity_menu_speedtest), "http://speedof.me/api/doc/sample_advanced.html");

                } else if (position == 3) {
                    ContextUtil.startActivity(getContext(), AboutActivity.class);

                }

                HomeActivity home = (HomeActivity) getActivity();
                if (home != null) {
                    home.closeDrawer();
                }
            }
        }
    };
}
