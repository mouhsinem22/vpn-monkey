package com.vm.shadowsocks.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.StringRes;

import com.monkey.vpn.R;

/**
 * Created by Luis
 * on 11/5/17.
 */

public class PreferenceHelper {
    private static final String CONFIG_URL_KEY = "CONFIG_URL_KEY";
    public static final String SHADOWSOCKS_PROXY_URL = "shadowsocksProxyUrl";

    private Context mContext;
    private static PreferenceHelper sInstance;

    private PreferenceHelper(Context context) {
        mContext = context;
    }

    public static PreferenceHelper get(Context context) {
        if (sInstance == null) {
            sInstance = new PreferenceHelper(context);
        }
        return sInstance;
    }

    private Context getContext() {
        return mContext;
    }

    private String str(@StringRes int resId) {
        return getContext().getString(resId);
    }

    public void setLong(String key, long value) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        sp.edit().putLong(key, value).apply();
    }

    public long getLong(String key, long defValue) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        return sp.getLong(key, defValue);
    }

    public void setBoolean(String key, boolean value) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        sp.edit().putBoolean(key, value).apply();
    }

    public boolean getBoolean(String key, boolean defValue) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        return sp.getBoolean(key, defValue);
    }

    public String getString(String key, String defValue) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        return sp.getString(key, defValue);
    }

//    public String readProxyUrl() {
//        SharedPreferences preferences = getContext().getSharedPreferences(SHADOWSOCKS_PROXY_URL, Context.MODE_PRIVATE);
//        return preferences.getString(CONFIG_URL_KEY, getContext().getString(R.string.default_config_url));
//    }

    public void setProxyUrl(String ProxyUrl) {
        SharedPreferences preferences = getContext().getSharedPreferences(SHADOWSOCKS_PROXY_URL, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(CONFIG_URL_KEY, ProxyUrl);
        editor.apply();
    }

    public void writeServerListValue(int value) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        sp.edit().putString(getContext().getString(R.string.key_setting_server_list), "" + value).apply();
    }

    public int readServerListValue() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        String v = sp.getString(getContext().getString(R.string.key_setting_server_list), "0");
        return Integer.parseInt(v);
    }

    public String readServerListEntry() {
        String[] entries = getContext().getResources().getStringArray(R.array.setting_activity_server_list_entries);
        return entries[readServerListValue()];
    }

    public void writeServerKey(String serverKey) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        sp.edit().putString(getContext().getString(R.string.server_key), "" + serverKey).apply();
    }

    public String readServerKey() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getContext());
        String v = sp.getString(getContext().getString(R.string.server_key), "");
        return v;
    }

    public boolean isNewUserAdClicked() {
        return getBoolean(str(R.string.new_user_ad_clicked_key), false);
    }

    public void setNewUserAdClicked(boolean clicked) {
        setBoolean(str(R.string.new_user_ad_clicked_key), clicked);
    }
}
