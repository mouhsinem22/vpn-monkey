package com.vm.shadowsocks.model;


import com.monkey.vpn.R;

import java.util.HashMap;

/**
 * Created by Administrator
 * on 2018/6/14 0014.
 */

public class Flags {

    public static HashMap<String, Integer> sMap = new HashMap<>();
    static {
        sMap.put("AE", R.drawable.server_activity_flag_ae);
        sMap.put("AR", R.drawable.server_activity_flag_ar);
        sMap.put("AU", R.drawable.server_activity_flag_au);
        sMap.put("BR", R.drawable.server_activity_flag_br);
        sMap.put("CA", R.drawable.server_activity_flag_ca);
        sMap.put("CH", R.drawable.server_activity_flag_ch);
        sMap.put("CN", R.drawable.server_activity_flag_cn);
        sMap.put("DE", R.drawable.server_activity_flag_de);
        sMap.put("DZ", R.drawable.server_activity_flag_dz);
        sMap.put("ES", R.drawable.server_activity_flag_es);
        sMap.put("FR", R.drawable.server_activity_flag_fr);
        sMap.put("GB", R.drawable.server_activity_flag_gb);
        sMap.put("HK", R.drawable.server_activity_flag_hk);
        sMap.put("IE", R.drawable.server_activity_flag_ie);
        sMap.put("IN", R.drawable.server_activity_flag_in);
        sMap.put("IT", R.drawable.server_activity_flag_it);
        sMap.put("JP", R.drawable.server_activity_flag_jp);
        sMap.put("KR", R.drawable.server_activity_flag_kr);
        sMap.put("RU", R.drawable.server_activity_flag_ru);
        sMap.put("SA", R.drawable.server_activity_flag_sa);
        sMap.put("SG", R.drawable.server_activity_flag_sg);
        sMap.put("TW", R.drawable.server_activity_flag_tw);
        sMap.put("US", R.drawable.server_activity_flag_us);
    }

}
