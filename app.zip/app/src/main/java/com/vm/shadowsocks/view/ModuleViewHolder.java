package com.vm.shadowsocks.view;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.monkey.vpn.R;
import com.vm.shadowsocks.model.Flags;
import com.vm.shadowsocks.model.IModule;
import com.vm.shadowsocks.model.SsServer;

import util.com.bignerdranch.expandablerecyclerview.ChildViewHolder;

/**
 * Created by Administrator on 2017/4/7 0007.
 */

public class ModuleViewHolder extends ChildViewHolder {

    private Context mContext;
    private View mRootView;
    private TextView mNameView;
    private ImageView mFlagView;
    private RelativeLayout mContentRl;
    private ImageView mMenuItv;
    private RelativeLayout mMenuRl;
    private TextView mSignal;

    public ModuleViewHolder(View itemView) {
        super(itemView);
        mContext = itemView.getContext();
        mRootView = itemView;
        mNameView =  itemView.findViewById(R.id.tv_name);
        mFlagView = itemView.findViewById(R.id.iv_flag);
        mContentRl = itemView.findViewById(R.id.rl_content);
        mMenuItv = itemView.findViewById(R.id.itv_menu);
        mMenuRl = itemView.findViewById(R.id.rl_menu);
        mSignal = itemView.findViewById(R.id.signal);
    }

    public void bind(IModule module, int index, View.OnClickListener click, View.OnLongClickListener longClick) {
        if (module instanceof SsServer) {
            SsServer ssServer = (SsServer) module;
            mNameView.setText(module.getHost());
            itemView.setTag(index);
            itemView.setOnClickListener(click);
            mMenuRl.setTag(module);
            if (longClick != null) {
                itemView.setOnLongClickListener(longClick);
            }

            SsServer server = (SsServer) module;
            mNameView.setText(String.format("%1$s (%2$s)", server.country, server.district));
            Integer resId = Flags.sMap.get(server.country);
            mFlagView.setImageResource(resId != null ? resId : R.drawable.server_activity_flag_default);
            Drawable checkbox_on = mContext.getResources().getDrawable(R.drawable.server_checkbox_on);
            mMenuItv.setImageDrawable(server.checked ? checkbox_on : null);

            mSignal.setText(ssServer.signal + "%");
        }

//        if (PackageUtil.isPackageInstalled(mContext, module.getPkgName())) {
//            mMenuRl.setVisibility(View.GONE);
//        } else {
//            mMenuRl.setVisibility(View.VISIBLE);
//        }
//
//        if ("imoblife.toolbox.full.prokey".equals(module.getPkgName())) {
//            mMenuItv.setImageDrawable(SkinManager.getInstance().getDrawable(R.drawable.plugin_icon_recommend));
//        }
//
//        if (module instanceof ModuleModel) {
//            if (((ModuleModel) module).isNew()) {
//                mNewIcon.setVisibility(View.VISIBLE);
//            } else {
//                mNewIcon.setVisibility(View.GONE);
//            }
//        } else {
//            mNewIcon.setVisibility(View.GONE);
//        }
    }

    public View getRootView() {
        return mRootView;
    }
}
