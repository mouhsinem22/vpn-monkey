package com.vm.shadowsocks.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.monkey.vpn.R;
import com.vm.shadowsocks.core.LocalVpnService;

import util.com.google.firebase.FirebaseUtil;


@SuppressLint("NewApi")
public class WebViewActivity extends Activity {
    public static final String TAG = "WebViewActivity";
    public static final String WEBVIEW_TITLE = "title";
    public static final String WEBVIEW_URL = "url";

    private WebView webview;
//    private MaterialDialog dialog;
    private LinearLayout titlebar;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.webview);

        String title = getIntent().getStringExtra(WEBVIEW_TITLE);
        setTitle(title);

        String url = getIntent().getStringExtra(WEBVIEW_URL);
        webview = (WebView) findViewById(R.id.webview_wv);
        WebSettings ws = webview.getSettings();
        if (ws != null) {
            ws.setJavaScriptEnabled(true);
            ws.setLoadWithOverviewMode(true);
            ws.setUseWideViewPort(true);
        }
        webview.setWebViewClient(client);
        webview.loadUrl(url);
        webview.setWebChromeClient(wvcc);


        if (android.os.Build.VERSION.SDK_INT >= 21) {
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(webview, true);
        } else {
            CookieManager.getInstance().setAcceptCookie(true);
        }

        titlebar = (LinearLayout) findViewById(R.id.titlebar);
        titlebar.setOnClickListener(mOnClick);

        FirebaseUtil.sendEvent(getContext(), TAG, "url", url);
    }

    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
//        dialog = new MaterialDialog.Builder(getActivity())
//                .progressIndeterminateStyle(false)
//                .progress(true, 0)
//                .build();
//        dialog.setContent(getString(R.string.loading));
//        dialog.setCancelable(true);
//        dialog.setOnCancelListener(new OnCancelListener() {
//            public void onCancel(DialogInterface dialog) {
//                if (webview != null) {
//                    webview.stopLoading();
//                }
//            }
//        });

        if (LocalVpnService.IsRunning) {
            FirebaseUtil.startTcpPingTrace(getContext(),"SpeedTest_Ping_google", "google.com");
            FirebaseUtil.startTcpPingTrace(getContext(),"SpeedTest_Ping_facebook", "facebook.com");
            FirebaseUtil.startTcpPingTrace(getContext(),"SpeedTest_Ping_twitter", "twitter.com");
            FirebaseUtil.startTcpPingTrace(getContext(),"SpeedTest_Ping_telegram", "telegram.org");
            FirebaseUtil.startTcpPingTrace(getContext(),"SpeedTest_Ping_youtube", "youtube.com");
            FirebaseUtil.startTcpPingTrace(getContext(),"SpeedTest_Ping_youku", "youku.com");
        }
    }

    protected void onDestroy() {
        super.onDestroy();
//        if (dialog != null) {
//            dialog.dismiss();
//            dialog = null;
//        }

        if (webview != null) {
            webview.destroy();
            webview = null;
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webview.canGoBack()) {
            webview.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private Context getContext() {
        return getApplicationContext();
    }

    public static void loadUrl(Context context, String title, String url) {
        Intent i = new Intent(context, WebViewActivity.class);
        i.putExtra(WEBVIEW_TITLE, title);
        i.putExtra(WEBVIEW_URL, url);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    private WebViewClient client = new WebViewClient() {
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            try {
//                if (dialog != null) {
//                    dialog.show();
//                }
//
//                if (ContextUtil.isAppStoreUrl(url)) {
//                    ContextUtil.openUrlInGP(getContext(), url);
//                    finish();
//                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void onReceivedError(WebView view, int errorCode,
                                    String description, String failingUrl) {
            try {
//                if (dialog != null) {
//                    dialog.dismiss();
//                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            try {
//                if (dialog != null) {
//                    dialog.dismiss();
//                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private WebChromeClient wvcc = new WebChromeClient() {
        public void onReceivedTitle(WebView view, String title) {
            TextView title_tv = (TextView) findViewById(R.id.title_tv);
            if (title_tv != null) {
                title_tv.setText(title);
            }
        }
    };

    public String getTrackModule() {
        return getClass().getSimpleName();
    }

//    @Override
//    public boolean isTrackEnabled() {
//        return false;
//    }


    private View.OnClickListener mOnClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.titlebar) {
                finish();
            }
        }
    };
}
