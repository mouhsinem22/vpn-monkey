package com.vm.shadowsocks.ad;

import android.content.Context;

import com.vm.shadowsocks.firebase.remoteconfig.RemoteConfigHelper;

import util.android.content.ContextUtil;
import util.android.content.pm.PackageUtil;

/**
 * Created by Administrator
 * on 2018/6/12 0012.
 */

public class Ad {
    
    public static void showInterstitial(Context context) {
        if (RemoteConfigHelper.get().isAdEnabled()) {
            boolean supported = PackageUtil.isPackageInstalled(context, "com.facebook.katana")
                    || PackageUtil.isPackageInstalled(context, "com.facebook.lite")
                    || PackageUtil.isPackageInstalled(context, "com.facebook.orca")
                    || PackageUtil.isPackageInstalled(context, "com.instagram.android");
            boolean loaded = Facebook.get(context).mNativeAd.isAdLoaded();
            if (supported && loaded) {
                ContextUtil.startActivity(context, FacebookNativeAdActivity.class);
            } else {
                Admob.get(context).showInterstitial();
            }
        }
    }
    
}
