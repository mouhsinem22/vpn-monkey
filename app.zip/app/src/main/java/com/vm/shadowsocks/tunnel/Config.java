package com.vm.shadowsocks.tunnel;

import java.net.InetSocketAddress;

public abstract class Config {
    public InetSocketAddress ServerAddress;
}
