package com.vm.shadowsocks.ad;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.*;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import util.com.google.firebase.FirebaseUtil;

/**
 * Created by Administrator
 * on 2018/4/17 0017.
 */
public class Facebook {

    private static Facebook sInstance;
    private Context mContext;
    public NativeAd mNativeAd;

    private Facebook(Context context) {
        mContext = context;
    }

    public static Facebook get(Context context) {
        if (sInstance == null) {
            sInstance = new Facebook(context);
        }
        return sInstance;
    }

    private Context getContext() {
        return mContext;
    }

    public void loadNativeAd(final Context context) {
//        FirebaseUtil.sendEvent(getContext(), "NativeAd_load");
//        mNativeAd = new NativeAd(context, "204380193497320_204380320163974");
//        mNativeAd.setAdListener(new NativeAdListener() {
//            @Override
//            public void onMediaDownloaded(Ad ad) {
//                FirebaseUtil.sendEvent(getContext(), "NativeAd_onMediaDownloaded");
//            }
//
//            @Override
//            public void onError(Ad ad, AdError adError) {
//                Bundle params = new Bundle();
//                params.putString("Ad", ad.getPlacementId());
//                params.putLong("AdError", adError.getErrorCode());
//                FirebaseUtil.sendEvent(getContext(), "NativeAd_onError", params);
//            }
//
//            @Override
//            public void onAdLoaded(Ad ad) {
//                FirebaseUtil.sendEvent(getContext(), "NativeAd_onAdLoaded");
//                // Facebook.this.showNativeAd(activity);
//            }
//
//            @Override
//            public void onAdClicked(Ad ad) {
//                FirebaseUtil.sendEvent(getContext(), "NativeAd_onAdClicked", "PlacementId", ad.getPlacementId());
//            }
//
//            @Override
//            public void onLoggingImpression(Ad ad) {
//                FirebaseUtil.sendEvent(getContext(), "NativeAd_onLoggingImpression", "PlacementId", ad.getPlacementId());
//            }
//        });
//
//        // Request an ad
//        mNativeAd.loadAd();
    }

    public void showNativeAd(Activity activity) {
//        FirebaseUtil.sendEvent(getContext(), "NativeAd_show");
//        if (mNativeAd == null || !mNativeAd.isAdLoaded()) {
//            return;
//        }
//        mNativeAd.unregisterView();
//
//        // Add the Ad view into the ad container.
//        RelativeLayout nativeAdContainer = (RelativeLayout) activity.findViewById(R.id.native_ad_container);
//        LayoutInflater inflater = LayoutInflater.from(activity);
//        // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
//        LinearLayout adView = (LinearLayout) inflater.inflate(R.layout.facebook_nativead, nativeAdContainer, false);
//        nativeAdContainer.addView(adView);
//
//        // Create native UI using the ad metadata.
//        ImageView nativeAdIcon = (ImageView) adView.findViewById(R.id.native_ad_icon);
//        TextView nativeAdTitle = (TextView) adView.findViewById(R.id.native_ad_title);
//        MediaView nativeAdMedia = (MediaView) adView.findViewById(R.id.native_ad_media);
//        TextView nativeAdSocialContext = (TextView) adView.findViewById(R.id.native_ad_social_context);
//        TextView nativeAdBody = (TextView) adView.findViewById(R.id.native_ad_body);
//        Button nativeAdCallToAction = (Button) adView.findViewById(R.id.native_ad_call_to_action);
//
//        // Set the Text.
//        nativeAdTitle.setText(mNativeAd.getAdHeadline());
//        nativeAdSocialContext.setText(mNativeAd.getAdSocialContext());
//        nativeAdBody.setText(mNativeAd.getAdBodyText());
//        nativeAdCallToAction.setText(mNativeAd.getAdCallToAction());
//
//        // Download and display the ad icon.
//        NativeAd.Image adIcon = mNativeAd.getAdIcon();
////        NativeAd.downloadAndDisplayImage(adIcon, nativeAdIcon);
////        Picasso.with(getContext()).load(adIcon.getUrl()).placeholder(R.drawable.luckad).into(nativeAdIcon);
////        Picasso.with(getContext()).load(adIcon.getUrl()).placeholder(R.drawable.luckad).into(nativeAdIcon);
////        FirebaseUtil.sendEvent(getContext(), "NativeAd_show", "Url", adIcon.getUrl());
//
//        // Download and display the cover image.
////        nativeAdMedia.setNativeAd(mNativeAd);
//
//        // Add the AdChoices icon
//        LinearLayout adChoicesContainer = (LinearLayout) activity.findViewById(R.id.ad_choices_container);
//        AdChoicesView adChoicesView = new AdChoicesView(activity, mNativeAd, true);
//        adChoicesContainer.addView(adChoicesView);
//
//        // Register the Title and CTA button to listen for clicks.
//        List<View> clickableViews = new ArrayList<>();
//        clickableViews.add(nativeAdTitle);
//        clickableViews.add(nativeAdCallToAction);
//        mNativeAd.registerViewForInteraction(nativeAdContainer,nativeAdMedia);
    }

}
