package com.vm.shadowsocks.ui;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.support.annotation.Nullable;
import android.util.Log;

import com.crashlytics.android.Crashlytics;
import com.monkey.vpn.BuildConfig;
import com.monkey.vpn.R;

/**
 * Created by Luis on 11/5/17.
 *
 */

public class SettingActivity extends PreferenceActivity {
    private static final String TAG = "SettingActivity";

    private SharedPreferences mPreferences;
    private ListPreference mServerList;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.setting_activity_preference);
        setContentView(R.layout.setting_activity);

        mPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        mPreferences.registerOnSharedPreferenceChangeListener(mOnChanged);

        mServerList = (ListPreference) findPreference(getString(R.string.key_setting_server_list));
        mServerList.setSummary(mServerList.getEntry());
        mServerList.setOnPreferenceClickListener(mOnClick);
    }

    private Context getContext() {
        return getApplicationContext();
    }

    private SharedPreferences.OnSharedPreferenceChangeListener mOnChanged = new SharedPreferences.OnSharedPreferenceChangeListener() {
        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            if (getString(R.string.key_setting_server_list).equals(key)) {
                mServerList.setSummary(mServerList.getEntry());
            }
        }
    };

    private Preference.OnPreferenceClickListener mOnClick = new Preference.OnPreferenceClickListener() {
        @Override
        public boolean onPreferenceClick(Preference preference) {
            if (BuildConfig.DEBUG) {
                Log.i(TAG, "Firebase: crash test");
                Crashlytics.setString("screen", TAG);
                //Crashlytics.getInstance().crash();
            }
            return false;
        }
    };
}
