package com.vm.shadowsocks.view;

import android.support.annotation.NonNull;
import android.view.View;

import util.com.bignerdranch.expandablerecyclerview.ParentViewHolder;

/**
 * Created by Luis on 11/9/17.
 *
 */

public class HeaderViewHolder extends ParentViewHolder {
    /**
     * Default constructor.
     *
     * @param itemView The {@link View} being hosted in this ViewHolder
     */
    public HeaderViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}