package com.vm.shadowsocks.view;

import android.view.View;
import android.widget.TextView;

import com.monkey.vpn.R;
import com.vm.shadowsocks.model.ICategory;

import util.com.bignerdranch.expandablerecyclerview.ParentViewHolder;

/**
 * Created by Administrator on 2017/4/7 0007.
 *
 */

public class CategoryViewHolder extends ParentViewHolder {

    private TextView mTextView;
    private View mDividerView;

    public CategoryViewHolder(View itemView) {
        super(itemView);
        mTextView = (TextView) itemView.findViewById(R.id.tv_name);
        mDividerView = itemView.findViewById(R.id.divider_view);
    }

    public void bind(ICategory category) {
        mTextView.setText(category.getName());
        mDividerView.setVisibility(View.GONE);
    }
}
