package com.vm.shadowsocks.ad;

import android.content.Context;
import android.util.Log;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.monkey.vpn.BuildConfig;
import com.monkey.vpn.R;
import com.vm.shadowsocks.model.PreferenceHelper;

import util.com.google.firebase.FirebaseUtil;

/**
 * Created by Luis
 * on 11/8/17.
 */

public class Admob {
    public static final String TAG = "Admob";

    private static Admob sInstance;

    private Context mContext;
    private InterstitialAd mInterstitialAd;
    private RewardedVideoAd mRewardedVideoAd;

    private Admob(Context context) {
        mContext = context;
    }

    public static Admob get(Context context) {
        if (sInstance == null) {
            sInstance = new Admob(context);
        }
        return sInstance;
    }

    private Context getContext() {
        return mContext;
    }

    public String getAppId() {
        return mContext.getString(R.string.admob_app_id);
    }

    public void onCreate(Context context) {
        mContext = context;

        loadInterstitial();
    }

    private void loadInterstitial() {
        FirebaseUtil.sendEvent(getContext(), "InterstitialAd_loadAd");
        mInterstitialAd = new InterstitialAd(mContext);
        mInterstitialAd.setAdUnitId(mContext.getString(R.string.admob_ad_unit_id_2));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClicked() {
                super.onAdClicked();
                PreferenceHelper.get(getContext()).setNewUserAdClicked(true);
            }
        });
    }

    public void onDestory(Context context) {
        mRewardedVideoAd.setRewardedVideoAdListener(null);
        mRewardedVideoAd.destroy(context);
    }

    public void loadRewardedVideoAd() {
        FirebaseUtil.sendEvent(getContext(), "RewardedVideoAd_loadAd");
        // Use an activity context to get the rewarded video instance.
        mRewardedVideoAd = MobileAds.getRewardedVideoAdInstance(getContext());
        mRewardedVideoAd.setRewardedVideoAdListener(new RewardedVideoAdListener() {
            @Override
            public void onRewardedVideoAdLoaded() {
                Log.i(TAG, "loadRewardedVideoAd onRewardedVideoAdLoaded ");

            }

            @Override
            public void onRewardedVideoAdOpened() {
                Log.i(TAG, "loadRewardedVideoAd onRewardedVideoAdOpened ");
                PreferenceHelper.get(getContext()).setNewUserAdClicked(true);
            }

            @Override
            public void onRewardedVideoStarted() {
                Log.i(TAG, "loadRewardedVideoAd onRewardedVideoStarted ");

            }

            @Override
            public void onRewardedVideoAdClosed() {
                Log.i(TAG, "loadRewardedVideoAd onRewardedVideoAdClosed ");

            }

            @Override
            public void onRewarded(RewardItem rewardItem) {
                Log.i(TAG, "loadRewardedVideoAd onRewarded ");

            }

            @Override
            public void onRewardedVideoAdLeftApplication() {
                Log.i(TAG, "loadRewardedVideoAd onRewardedVideoAdLeftApplication ");

            }

            @Override
            public void onRewardedVideoAdFailedToLoad(int i) {
                Log.i(TAG, "loadRewardedVideoAd onRewardedVideoAdFailedToLoad " + i);

            }

            @Override
            public void onRewardedVideoCompleted() {
                Log.i(TAG, "loadRewardedVideoAd onRewardedVideoCompleted ");

            }
        });
        mRewardedVideoAd.loadAd(getContext().getString(R.string.admob_ad_unit_id_3), new AdRequest.Builder().build());
    }

    public void showRewardedVideoAd() {
        FirebaseUtil.sendEvent(getContext(), "RewardedVideoAd_show");
        if (mRewardedVideoAd != null && mRewardedVideoAd.isLoaded()) {
            mRewardedVideoAd.show();
        }
    }

    public void showInterstitial() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
            FirebaseUtil.sendEvent(getContext(), "InterstitialAd_show");
        } else {
            Log.d(TAG, "The interstitial wasn't loaded yet.");
        }
    }

    public void loadAdmobBanner(AdView mAdView) {
        FirebaseUtil.sendEvent(getContext(), "AdView_loadAd");

        MobileAds.initialize(getContext(), Admob.get(getContext()).getAppId());
        AdRequest.Builder arb = new AdRequest.Builder();
        if (BuildConfig.DEBUG) {
            arb.addTestDevice("5CCE8015CC41C7B1407D241E9EA0F92E");
        }
        AdRequest adRequest = arb.build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
                FirebaseUtil.sendEvent(getContext(), "AdView_onAdLoaded");
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                // Code to be executed when an ad request fails.
                FirebaseUtil.sendEvent(getContext(), "AdView_onAdFailedToLoad", "errorCode", errorCode);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that covers the screen.
                PreferenceHelper.get(getContext()).setNewUserAdClicked(true);
                FirebaseUtil.sendEvent(getContext(), "AdView_onAdOpened");
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
                FirebaseUtil.sendEvent(getContext(), "AdView_onAdLeft");
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when when the user is about to return to the app after tapping on an ad.
                FirebaseUtil.sendEvent(getContext(), "AdView_onAdClosed");
            }
        });
    }

}
