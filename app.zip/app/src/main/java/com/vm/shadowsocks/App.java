package com.vm.shadowsocks;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;

import util.com.google.firebase.FirebaseUtil;

//import com.tencent.stat.MtaSDkException;
//import com.tencent.stat.StatConfig;
//import com.tencent.stat.StatService;


/**
 * Created by Luis on 11/7/17.
 */

public class App extends Application {

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();

        initMTA();
        FirebaseUtil.sendEvent(getContext(), "App_onCreate");
    }

    private void initMTA() {
//        try {
//            String key = /*StatConfig.getAppKey(getContext())*/ "A99ZD4MN4NNV";
//            String ver = com.tencent.stat.common.StatConstants.VERSION;
//            Log.i("MtaSDK", "key " + key + ", " + ver);
//            StatService.startStatService(getContext(), key, ver);
//        } catch (MtaSDkException e) {
//            e.printStackTrace();
//            Log.e("MtaSDK", "MtaSDkException " + e);
//        }
    }

    private Context getContext() {
        return getApplicationContext();
    }
}
