package com.vm.shadowsocks.ui;

import android.app.Activity;
import android.os.Bundle;

import com.monkey.vpn.R;


/**
 * Created by Luis
 * on 11/5/17.
 */

public class AboutActivity extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_activity);
    }

}