package com.vm.shadowsocks.ui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdView;
import com.google.firebase.perf.FirebasePerformance;
import com.google.firebase.perf.metrics.AddTrace;
import com.google.firebase.perf.metrics.Trace;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
//import com.tencent.stat.StatService;
import com.monkey.vpn.R;
import com.vm.shadowsocks.ad.Ad;
import com.vm.shadowsocks.ad.Admob;
import com.vm.shadowsocks.ad.Facebook;
import com.vm.shadowsocks.core.AppInfo;
import com.vm.shadowsocks.core.AppProxyManager;
import com.vm.shadowsocks.core.LocalVpnService;
import com.vm.shadowsocks.firebase.remoteconfig.RemoteConfigHelper;
import com.vm.shadowsocks.model.Flags;
import com.vm.shadowsocks.model.PreferenceHelper;
import com.vm.shadowsocks.model.SsServer;
import com.vm.shadowsocks.model.http.OkHttp3Util;
import com.vm.shadowsocks.util.android.os.ModernAsyncTask;

import java.net.NetworkInterface;
import java.util.Calendar;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;

import util.android.content.pm.PackageUtil;
import util.com.google.firebase.FirebaseUtil;

/**
 * Created by Luis
 * on 11/5/17.
 *
 */

public class HomeActivity extends AppCompatActivity {
    public static final String TAG = "HomeActivity";

    private static final int START_VPN_SERVICE_REQUEST_CODE = 1985;
    public static final int REQUEST_CODE_SERVER_CHANGE = 1;
    public static final String EXTRA_REQUEST_PERMISSION_NEEDED = "extra_request_permission_needed";

    public static final int MSG_CONNECT = 1;
    public static final int MSG_DISCONNECT = 2;

    private ConnectPresent mConnectPresent;
    private ConnectTask mConnectTask;

    private TextView textViewProxyApp;
    private Calendar mCalendar;
    private ImageView mMenuServer;

    private Toolbar mToolbar;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;

    private RelativeLayout mSwitchLayout;

    private Handler mHandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            Log.i(TAG, "STATE::handleMessage: " + ModernAsyncTask.isTaskRunning(mConnectTask) + ", " + mConnectPresent.mView.isRunning());
            if (ModernAsyncTask.isTaskRunning(mConnectTask)
                    || mConnectPresent.mView.isRunning()) {
                return;
            }

            if (MSG_CONNECT == msg.what) {
                Log.i(TAG, "STATE::handleMessage MSG_CONNECT");
                Intent intent = LocalVpnService.prepare(getContext());
                if (intent == null) {
                    mConnectTask = new ConnectTask();
                    mConnectTask.execute();
                } else {
                    startActivityForResult(intent, START_VPN_SERVICE_REQUEST_CODE);
                }

            } else if (MSG_DISCONNECT == msg.what) {
                Log.i(TAG, "STATE::handleMessage MSG_DISCONNECT");
                LocalVpnService.IsRunning = false;
                mConnectPresent.mView.stopAnimator();

            }
        }
    };

    @Override
    @AddTrace(name = TAG + "_onCreate")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity_with_drawer);

        Log.i(TAG, "onCreate");
        FirebaseUtil.sendEvent(getContext(), TAG);

        ConnectModel connectModel = new ConnectModel(OkHttp3Util.getCurrentServer(getContext()));
        ConnectView connectView = new ConnectView(findViewById(R.id.connect_layout));
        mConnectPresent = new ConnectPresent(connectModel, connectView);
        mConnectPresent.mView.mIcon.setOnClickListener(mOnClick);
        mConnectPresent.mView.mButton.setOnClickListener(mOnClick);
        mConnectPresent.mView.mStatus.setText(R.string.vpn_disconnected_status);
        mConnectPresent.mView.mTime.setText(mConnectPresent.getCurrentServerName());
        boolean connected = (checkVpnConnected() && LocalVpnService.IsRunning);
        mConnectPresent.setState(connected ? ConnectModel.STATE_CONNECTED : ConnectModel.STATE_DISCONNECTED);

        mCalendar = Calendar.getInstance();
        LocalVpnService.addOnStatusChangedListener(mOnStatusChange);

        //Pre-App Proxy
        if (AppProxyManager.isLollipopOrAbove) {
            new AppProxyManager(this);
            textViewProxyApp = (TextView) findViewById(R.id.textViewAppSelectDetail);
        }

        RemoteConfigHelper.get().fetch();

        if (RemoteConfigHelper.get().isAdEnabled()) {
            Admob.get(getContext()).onCreate(getContext());
            Admob.get(getContext()).loadRewardedVideoAd();
        }

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        initDrawer();

        mMenuServer = findViewById(R.id.menu_server);
        mMenuServer.setOnClickListener(mOnClick);

        if (mConnectPresent.mModel.mServer != null) {
            Integer resId = Flags.sMap.get(mConnectPresent.mModel.mServer.country);
            mMenuServer.setImageResource(resId != null ? resId : R.drawable.server_activity_flag_default);
        }

        mSwitchLayout = (RelativeLayout) findViewById(R.id.switch_layout);
        mSwitchLayout.setOnClickListener(mOnClick);

        if (RemoteConfigHelper.get().isAdEnabled()) {
            AdView admob_banner = findViewById(R.id.admob_banner);
            Admob.get(getContext()).loadAdmobBanner(admob_banner);

            Facebook.get(getContext()).loadNativeAd(getContext());
        }

        initRequestPermission();
    }



    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "STATE::onResume");

        if (AppProxyManager.isLollipopOrAbove) {
            if (AppProxyManager.Instance.proxyAppInfo.size() != 0) {
                String tmpString = "";
                for (AppInfo app : AppProxyManager.Instance.proxyAppInfo) {
                    tmpString += app.getAppLabel() + ", ";
                }
                textViewProxyApp.setText(tmpString);
            }
        }

        //StatService.onResume(getContext());
        checkForbiddenCountry();
    }

    private void checkForbiddenCountry() {
        Log.i(TAG, "checkForbiddenCountry " + Locale.getDefault().getCountry());
        if (Locale.getDefault().getCountry().equals("CN")
                && !RemoteConfigHelper.get().isAppForbiddenCountryEnabled()) {
            AlertDialog.Builder adb = new AlertDialog.Builder(getActivity());
            adb.setCancelable(false);
            adb.setTitle("Country or district forbidden");
            adb.setMessage("According to laws in your country or district, this app is forbidden to use. Please exit and uninstall, thank you.");
            adb.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    FirebaseUtil.sendEvent(getContext(), "ForbiddenCountry_onClick");
                    Process.killProcess(Process.myPid());
                }
            });
            FirebaseUtil.sendEvent(getContext(), "ForbiddenCountry_show");
            adb.show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        //StatService.onPause(getContext());
    }

    @Override
    @AddTrace(name = TAG + "_onDestroy")
    protected void onDestroy() {
        Log.i(TAG, "onDestroy");
        LocalVpnService.removeOnStatusChangedListener(mOnStatusChange);
        super.onDestroy();

        if (RemoteConfigHelper.get().isAdEnabled()) {
            Admob.get(getContext()).onDestory(getContext());
        }

        mConnectPresent.onDestroy();
    }

    private Context getContext() {
        return getApplicationContext();
    }

    private Activity getActivity() {
        return HomeActivity.this;
    }

    public boolean checkVpnConnected() {
        boolean res = false;

        try {
            Enumeration<NetworkInterface> niList = NetworkInterface.getNetworkInterfaces();
            if (niList != null) {
                for (NetworkInterface intf : Collections.list(niList)) {
                    if (!intf.isUp() || intf.getInterfaceAddresses().size() == 0) {
                        continue;
                    }
                    if ("tun0".equals(intf.getName()) || "ppp0".equals(intf.getName())) {
                        res = true;
                        break;
                    }
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }

        return res;
    }


    boolean isValidUrl(String url) {
        try {
            if (url == null || url.isEmpty())
                return false;

            if (url.startsWith("ss://")) {//file path
                return true;
            } else { //url
                Uri uri = Uri.parse(url);
                if (!"http".equals(uri.getScheme()) && !"https".equals(uri.getScheme()))
                    return false;
                if (uri.getHost() == null)
                    return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void startVPNService(String proxyUrl) {
        if (!isValidUrl(proxyUrl)) {
            return;
        }

        FirebaseUtil.sendEvent(getContext(), "ConnectView_startVPNService", "url", proxyUrl);
        mOnStatusChange.onLogReceived("starting...");
        LocalVpnService.ProxyUrl = proxyUrl;
        startService(new Intent(this, LocalVpnService.class));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        Log.i(TAG, "REQ::onActivityResult " + requestCode + ", " + resultCode);

        if (requestCode == START_VPN_SERVICE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Message msg = mHandler.obtainMessage(MSG_CONNECT);
                msg.sendToTarget();
            } else {
                mOnStatusChange.onLogReceived("canceled.");
            }
            return;
        }

        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanResult != null) {
            String ProxyUrl = scanResult.getContents();
            if (isValidUrl(ProxyUrl)) {
                //PreferenceHelper.get(getContext()).setProxyUrl(ProxyUrl);
            } else {
                Toast.makeText(getContext(), R.string.err_invalid_url, Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (REQUEST_CODE_SERVER_CHANGE == requestCode && RESULT_OK == resultCode) {
            Message msg = mHandler.obtainMessage(MSG_DISCONNECT);
            msg.sendToTarget();
            msg = mHandler.obtainMessage(MSG_CONNECT);
            msg.sendToTarget();
        }

        super.onActivityResult(requestCode, resultCode, intent);
    }

    class ConnectTask extends ModernAsyncTask<Void, Void, Void> {
        long connectingDuration = 0;
        Trace myTrace;

        ConnectTask() {
            myTrace = FirebasePerformance.getInstance().newTrace("ConnectTask_connectingDuration");
        }

        @Override
        @AddTrace(name = "ConnectTask_doInBackground")
        protected Void doInBackground(Void... voids) {
            SsServer server = OkHttp3Util.getCurrentServer(getContext());
            if (server != null) {
                mConnectPresent.setServer(server);
                mConnectPresent.updateServerName();

                String serverUrl = OkHttp3Util.convertServerToUrl(server);
                startVPNService(serverUrl);
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            Log.i(TAG, "STATE::onPreExecute ");
            myTrace.start();
            connectingDuration = System.currentTimeMillis();
            mConnectPresent.showConnectingAnimator();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Log.i(TAG, "STATE::onPostExecute ");
            myTrace.stop();
            connectingDuration = System.currentTimeMillis() - connectingDuration;
            FirebaseUtil.sendEvent(getContext(), "ConnectView_connect_duration", connectingDuration);

            if (mConnectPresent.mModel.mServer != null) {
                Integer resId = Flags.sMap.get(mConnectPresent.mModel.mServer.country);
                mMenuServer.setImageResource(resId != null ? resId : R.drawable.server_activity_flag_default);
            }
        }
    }

    private LocalVpnService.onStatusChangedListener mOnStatusChange = new LocalVpnService.onStatusChangedListener() {

        @SuppressLint("DefaultLocale")
        @Override
        public void onLogReceived(String logString) {
            mCalendar.setTimeInMillis(System.currentTimeMillis());
            logString = String.format("[%1$02d:%2$02d:%3$02d] %4$s\n",
                    mCalendar.get(Calendar.HOUR_OF_DAY),
                    mCalendar.get(Calendar.MINUTE),
                    mCalendar.get(Calendar.SECOND),
                    logString);

            System.out.println(logString);
        }

        @Override
        public void onStatusChanged(String statusStr, LocalVpnService.STATUS status) {
            onLogReceived(statusStr);
            Log.i(TAG, "STATE::onStatusChanged: " + statusStr + ", " + status);
            if (LocalVpnService.STATUS.CONNECTED == status) {
                mConnectPresent.setState(ConnectModel.STATE_CONNECTED);
                mConnectPresent.mModel.setTime(getContext());
                Ad.showInterstitial(getContext());

            } else if (LocalVpnService.STATUS.DISCONNECTED == status) {
                mConnectPresent.setState(ConnectModel.STATE_DISCONNECTED);

            } else if (LocalVpnService.STATUS.CONNECTING == status) {
                mConnectPresent.setState(ConnectModel.STATE_CONNECTING);

            }
        }
    };

    private View.OnClickListener mOnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (mConnectPresent.mView.mButton == v) {
                clickConnectView();

            } else if (mMenuServer == v) {
                FirebaseUtil.sendEvent(getContext(), "MenuServer_onClick");
                Intent i = new Intent(getContext(), ServersActivity.class);
                startActivityForResult(i, REQUEST_CODE_SERVER_CHANGE);

            } else if (mConnectPresent.mView.mIcon == v) {
                mConnectPresent.mView.mIcon.setProgress((float) (mConnectPresent.mView.mIcon.getProgress() + 0.01));

            } else if (mSwitchLayout == v) {
                clickConnectView();

            }

        }
    };

    private void clickConnectView() {
        Log.i(TAG, "STATE::clickConnectView " + mConnectPresent.mModel.mState);
        if (mConnectPresent.mModel.mState == ConnectModel.STATE_DISCONNECTED) {
            FirebaseUtil.sendEvent(getContext(), "ConnectView_onClick", 1);
            Message msg = mHandler.obtainMessage(MSG_CONNECT);
            msg.sendToTarget();

        } else if (mConnectPresent.mModel.mState == ConnectModel.STATE_CONNECTED) {
            FirebaseUtil.sendEvent(getContext(), "ConnectView_onClick", 0);
            Message msg = mHandler.obtainMessage(MSG_DISCONNECT);
            msg.sendToTarget();
        }
    }

    //@Override
    protected void initDrawer() {
        // 设置标题
        mToolbar.setTitle(R.string.app_name);
        mToolbar.setTitleTextColor(Color.parseColor("#FFFFFF"));
        mToolbar.inflateMenu(R.menu.home_activity_menu);
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                return false;
            }
        });


        // 将ToolBar设置为ActionBar
        setSupportActionBar(mToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);// 设置返回键可用
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // 创建返回键，并实现打开关/闭监听
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                mToolbar, R.string.btn_ok/*"R.string.draw_open"*/, R.string.btn_cancel/*"R.string.draw_close"*/) {
            @Override
            public void onDrawerOpened(View drawerView) {
                FirebaseUtil.sendEvent(getContext(), "ActionBarDrawer_onOpened");
                super.onDrawerOpened(drawerView);

            }

            @Override
            public void onDrawerClosed(View drawerView) {
                FirebaseUtil.sendEvent(getContext(), "ActionBarDrawer_onClosed");
                super.onDrawerClosed(drawerView);
                if (RemoteConfigHelper.get().isAdEnabled() && isFitNewUserAd(getContext())) {
                    Admob.get(getContext()).showRewardedVideoAd();
                }
            }
        };
        mDrawerToggle.syncState();
        mDrawerLayout.setDrawerListener(mDrawerToggle);

    }

    public void closeDrawer() {
        if (mDrawerLayout != null) {
            mDrawerLayout.closeDrawers();
        }
    }

    private void initRequestPermission() {
        Intent intent = getIntent();
        if (intent != null) {
            boolean request = intent.getBooleanExtra(EXTRA_REQUEST_PERMISSION_NEEDED, false);
            if (request) {
                clickConnectView();
            }
        }
    }

    public static boolean isFitNewUserAd(Context context) {
        return PackageUtil.isNewUser(context) && !PreferenceHelper.get(context).isNewUserAdClicked();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (RemoteConfigHelper.get().isAdEnabled() && isFitNewUserAd(getContext())) {
                PreferenceHelper.get(getContext()).setNewUserAdClicked(true);
                Admob.get(getContext()).showInterstitial();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}