package com.vm.shadowsocks.ui;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.monkey.vpn.R;

/**
 * Created by Luis
 * on 11/14/17.
 *
 */

public class ConnectView {

    Context mContext;
    View mRoot;
    TextView mStatus;
    TextView mTime;
//    ConnectPresent mPresent;

    LottieAnimationView mIcon;
    LottieAnimationView mButton;
    LottieAnimationView mButtonBg;

    ConnectView(View root) {
        mContext = root.getContext();

        mRoot = root;
        mStatus = root.findViewById(R.id.status);
        mTime = root.findViewById(R.id.time);

        mIcon = root.findViewById(R.id.icon);
        mIcon.setAnimation("empty_status_ver_color.json");
        mIcon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        mIcon.setScale(10f);
        mIcon.loop(true);

        mButton = root.findViewById(R.id.button);
        mButton.setAnimation("play_pause.json");
        mButton.setProgress(0f);

        mButtonBg = root.findViewById(R.id.button_bg);
    }

//    void setPresent(ConnectPresent present) {
//        this.mPresent = present;
//    }

    void stopAnimator() {
        Log.i(HomeActivity.TAG, "stopAnimator ");
    }

    boolean isRunning() {
        boolean res = false;

        return res;
    }

    public void setSwitcherOn(boolean isOn) {
        if (isOn) {
            mButton.setProgress(0f);//play icon
        } else {
            mButton.setProgress(1f);//pause icon
        }
    }
}
