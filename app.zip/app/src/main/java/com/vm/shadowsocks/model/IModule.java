package com.vm.shadowsocks.model;

import android.graphics.drawable.Drawable;

/**
 * Created by Administrator on 2017/4/6 0006.
 */

public interface IModule {
    String getKey();
    String getProtocol();
    String getMethod();
    String getPassword();
    String getHost();
    String getPort();
    String getEncode();
}
