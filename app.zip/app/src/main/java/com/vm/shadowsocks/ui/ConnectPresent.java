package com.vm.shadowsocks.ui;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;

import com.monkey.vpn.R;
import com.vm.shadowsocks.model.SsServer;

import util.TimeUtil;

/**
 * Created by Luis
 * on 11/14/17.
 */

public class ConnectPresent {
    static int HANDLE_TIME_LOOP = 0;
    static int HANDLE_SERVER_NAME = 1;

    ConnectModel mModel;
    ConnectView mView;

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (HANDLE_TIME_LOOP == msg.what) {
                mHandler.sendMessageDelayed(obtainMessage(HANDLE_TIME_LOOP), TimeUtil.SECOND);
                mView.mTime.setText(mModel.getDeltaTimeText(getContext()));

            } else if (HANDLE_SERVER_NAME == msg.what) {
                if (mModel.mServer != null) {
                    mView.mTime.setText(msg.obj.toString());
                }
            }
        }
    };

    public ConnectPresent(ConnectModel model, ConnectView view) {
        mModel = model;
        mView = view;
//        mView.setPresent(this);
    }

    Context getContext() {
        return mView.mContext;
    }

    void onDestroy() {
        mView.stopAnimator();
        mHandler.removeCallbacksAndMessages(null);
    }

    public void setServer(SsServer server) {
        mModel.mServer = server;
    }

    public void updateServerName() {
        Message msg = mHandler.obtainMessage(HANDLE_SERVER_NAME);
        msg.obj = getCurrentServerName();
        msg.sendToTarget();
    }

    public String getCurrentServerName() {
        if (mModel.mServer != null) {
            return mModel.mServer.country + " (" + mModel.mServer.district + ")";
        } else {
            return "";
        }
    }

    public void setState(int state) {
        Log.i(getClass().getSimpleName(), "STATE::setState " + state);
        mModel.mState = state;

        if (ConnectModel.STATE_CONNECTED == state) { // STATE_CONNECTED == 2
            showConnectedAnimator();

        } else if (ConnectModel.STATE_CONNECTING == state) { // STATE_CONNECTING == 1
            showConnectingAnimator();

        } else if (ConnectModel.STATE_DISCONNECTED == state) { // STATE_DISCONNECTED == 0
            showDisconnectedAnimator();
        }
    }

    private void showConnectedAnimator() {
        mView.mIcon.setSpeed(2f);
        if (!mView.mIcon.isAnimating()) {
            mView.mIcon.playAnimation();
        }

        mView.setSwitcherOn(false);
        mView.mButtonBg.pauseAnimation();
        mView.mButtonBg.setVisibility(View.INVISIBLE);

        mView.mStatus.setText(R.string.home_activity_connected);
        mView.mTime.setVisibility(View.VISIBLE);
        Message msg = mHandler.obtainMessage(HANDLE_TIME_LOOP);
        msg.sendToTarget();
    }

    public void showConnectingAnimator() {
        mHandler.removeCallbacksAndMessages(null);

        mView.mIcon.setSpeed(1f);
        mView.mIcon.playAnimation();

        if (!mView.mButtonBg.isAnimating()) {
            mView.mButtonBg.setSpeed(2f);
            mView.mButtonBg.playAnimation();
            mView.mButtonBg.setVisibility(View.VISIBLE);
        }

        mView.mStatus.setText(R.string.home_activity_connecting);
        if (mModel.mServer != null) {
            mView.mTime.setVisibility(View.VISIBLE);

            Message msg = mHandler.obtainMessage(HANDLE_SERVER_NAME);
            msg.obj = getCurrentServerName();
            msg.sendToTarget();
        } else {
            mView.mTime.setVisibility(View.INVISIBLE);
        }
    }

    private void showDisconnectedAnimator() {
        mHandler.removeCallbacksAndMessages(null);
        Message msg = mHandler.obtainMessage(HANDLE_SERVER_NAME);
        msg.obj = "";
        msg.sendToTarget();

        mView.mIcon.pauseAnimation();
        mView.mIcon.setProgress(0.7f);

        mView.setSwitcherOn(true);
        mView.mButtonBg.pauseAnimation();
        mView.mButtonBg.setVisibility(View.INVISIBLE);

        mView.mStatus.setText(R.string.vpn_disconnected_status);
        mView.mTime.setVisibility(View.INVISIBLE);

        if (mModel.mServer != null) {
            mView.mTime.setVisibility(View.VISIBLE);

            msg = mHandler.obtainMessage(HANDLE_SERVER_NAME);
            msg.obj = getCurrentServerName();
            msg.sendToTarget();
        } else {
            mView.mTime.setVisibility(View.INVISIBLE);
        }
    }

}
