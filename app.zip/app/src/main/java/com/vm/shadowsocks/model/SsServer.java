package com.vm.shadowsocks.model;

import android.graphics.drawable.Drawable;

/**
 * Created by Luis on 11/5/17.
 */

public class SsServer implements IModule {

    public static final String KEY_PROTOCOL = "protocol";
    public static final String KEY_METHOD = "method";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_HOST = "host";
    public static final String KEY_PORT = "port";
    public static final String KEY_ENCODE = "encode";
    public static final String KEY_COUNTRY = "country";
    public static final String KEY_DISTRICT = "district";
    public static final String KEY_STATE = "state";

    public static final String STATE_ENABLED = "enabled";
    public static final String STATE_DISABLED = "disabled";

    public String host;
    public String port;
    public String protocol;
    public String method;
    public String password;
    public String encode;
    public String country;
    public String district;
    public Resource resource;
    public String state;
    public int signal;

    public boolean checked;

    @Override
    public String getKey() {
        return host + ":" + port;
    }

    @Override
    public String getProtocol() {
        return protocol;
    }

    @Override
    public String getMethod() {
        return method;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getHost() {
        return host;
    }

    @Override
    public String getPort() {
        return port;
    }

    @Override
    public String getEncode() {
        return encode;
    }

    public static class Resource {
        public int iconRes;
        public int stringRes;
    }
}
