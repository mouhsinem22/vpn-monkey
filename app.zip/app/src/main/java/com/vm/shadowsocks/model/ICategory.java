package com.vm.shadowsocks.model;

import java.util.ArrayList;
import java.util.List;

import util.com.bignerdranch.expandablerecyclerview.model.Parent;

/**
 * Created by Administrator on 2017/4/6 0006.
 */

public interface ICategory extends Parent<IModule> {

    @Override
    List<IModule> getChildList();

    @Override
    boolean isInitiallyExpanded();

    String getName();

    void add(IModule module);

    void add(int location, IModule module);

    int getChildrenCount();
}
