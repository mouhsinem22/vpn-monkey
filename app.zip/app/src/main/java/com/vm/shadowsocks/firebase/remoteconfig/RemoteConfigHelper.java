package com.vm.shadowsocks.firebase.remoteconfig;

import android.support.annotation.NonNull;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.monkey.vpn.BuildConfig;
import com.monkey.vpn.R;


public class RemoteConfigHelper {
    private static final String TAG = "RemoteConfigHelper";

//    public static final String SS_CONFIG_SERVER_LIST_JSON = "ss_config_server_list_json";
    public static final String SS_CONFIG_SERVER_LIST_JSON = "ss_config_server_list_json_test";
    public static final String APP_FORBIDDEN_COUNTRY_ENABLED = "app_forbidden_country_enabled";
    public static final String AD_ENABLED = "ad_enabled";

    public static final String HOME_ACTIVITY_MENU_SETTING_ENABLED = "HomeActivity_Menu_Setting_Enabled";
    public static final String HOME_ACTIVITY_MENU_SPEED_TEST_ENABLED = "HomeActivity_Menu_SpeedTest_Enabled";

    private FirebaseRemoteConfig mFirebaseRemoteConfig;
    private int cacheExpiration = 3600; // 1 hour in seconds.

    private static RemoteConfigHelper sInstance;

    private RemoteConfigHelper() {
        init();
    }

    public static RemoteConfigHelper get() {
        if (sInstance == null) {
            sInstance = new RemoteConfigHelper();
        }

        return sInstance;
    }

    private void init() {
        // Get Remote Config instance.
        // [START get_remote_config_instance]
        mFirebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        // [END get_remote_config_instance]

        // Create a Remote Config Setting to enable developer mode, which you can use to increase
        // the number of fetches available per hour during development. See Best Practices in the
        // README for more information.
        // [START enable_dev_mode]
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setDeveloperModeEnabled(BuildConfig.DEBUG)
                .build();
        mFirebaseRemoteConfig.setConfigSettings(configSettings);
        // [END enable_dev_mode]

        // Set default Remote Config parameter values. An app uses the in-app default values, and
        // when you need to adjust those defaults, you set an updated value for only the values you
        // want to change in the Firebase console. See Best Practices in the README for more
        // information.
        // [START set_default_values]
        mFirebaseRemoteConfig.setDefaults(R.xml.remote_config_defaults);
        // [END set_default_values]

        // If your app is using developer mode, cacheExpiration is set to 0, so each fetch will
        // retrieve values from the service.
        if (mFirebaseRemoteConfig.getInfo().getConfigSettings().isDeveloperModeEnabled()) {
            cacheExpiration = 0;
        }
    }

    public void fetch() {
        mFirebaseRemoteConfig.fetch(cacheExpiration).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    mFirebaseRemoteConfig.activateFetched();
                }

                boolean adEnabled = mFirebaseRemoteConfig.getBoolean(AD_ENABLED);
                boolean forbidden = mFirebaseRemoteConfig.getBoolean(APP_FORBIDDEN_COUNTRY_ENABLED);
                boolean settingEnabled = mFirebaseRemoteConfig.getBoolean(HOME_ACTIVITY_MENU_SETTING_ENABLED);
                boolean speedEnabled = mFirebaseRemoteConfig.getBoolean(HOME_ACTIVITY_MENU_SPEED_TEST_ENABLED);
                String json = mFirebaseRemoteConfig.getString(SS_CONFIG_SERVER_LIST_JSON);
                Log.i(TAG, "Firebase:fetch settingEnabled " + settingEnabled
                        + ", speedEnabled " + speedEnabled
                        + ", adEnabled " + adEnabled
                        + ", forbidden " + forbidden
                        + ", json " + json
                );
            }
        });
    }

    public boolean getBoolean(String key, boolean defValue) {
        boolean res = defValue;
        if (mFirebaseRemoteConfig != null) {
            res = mFirebaseRemoteConfig.getBoolean(key);
        }
        return res;
    }

    public String loadServerListJson() {
        String res = mFirebaseRemoteConfig.getString(SS_CONFIG_SERVER_LIST_JSON);
        return res;
    }

    public boolean isMenuSpeedTestEnabled() {
        boolean res = getBoolean(HOME_ACTIVITY_MENU_SPEED_TEST_ENABLED, true);
        return res;
    }

    public boolean isAppForbiddenCountryEnabled() {
        boolean res = getBoolean(APP_FORBIDDEN_COUNTRY_ENABLED, true);
        return res;
    }

    public boolean isAdEnabled() {
        boolean res = getBoolean(AD_ENABLED, true);
        return res;
    }
}