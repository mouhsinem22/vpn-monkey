package com.vm.shadowsocks.ad;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import com.monkey.vpn.R;

//import com.tencent.stat.StatService;

/**
 * Created by Luis
 * on 11/5/17.
 *
 */

public class FacebookNativeAdActivity extends AppCompatActivity {
    public static final String TAG = "FacebookNativeAdActivity";

    private View.OnClickListener mOnLuckAdCloseClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.facebook_nativead_activity);
        Facebook.get(this).showNativeAd(this);

        ImageView luckad_close = findViewById(R.id.luckad_close);
        luckad_close.setOnClickListener(mOnLuckAdCloseClick);
    }

}