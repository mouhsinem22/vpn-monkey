package com.vm.shadowsocks.tile;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.support.annotation.RequiresApi;
import android.util.Log;

import com.monkey.vpn.R;
import com.vm.shadowsocks.core.AppProxyManager;
import com.vm.shadowsocks.core.LocalVpnService;
import com.vm.shadowsocks.model.SsServer;
import com.vm.shadowsocks.model.http.OkHttp3Util;
import com.vm.shadowsocks.ui.HomeActivity;
import com.vm.shadowsocks.util.android.os.ModernAsyncTask;

import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;

import util.Utils;
import util.com.google.firebase.FirebaseUtil;

@RequiresApi(api = Build.VERSION_CODES.N)
public class MyTileService extends TileService {

    private static final String TAG = "MyTileService";
    private ConnectTask mConnectTask;

    //    public final Tile getQsTile () {}

    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseUtil.sendEvent(getContext(), TAG);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        FirebaseUtil.sendEvent(getContext(), "Tile_onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    // 当 tile 被添加时的回调
    public void onTileAdded() {
        FirebaseUtil.sendEvent(getContext(), "Tile_onTileAdded");
    }

    // 当 tile 被移除时的回调
    public void onTileRemoved() {
        FirebaseUtil.sendEvent(getContext(), "Tile_onTileRemoved");
    }

    // 当 tile 可见时的回调
    public void onStartListening () {
        super.onStartListening();
        FirebaseUtil.sendEvent(getContext(), "Tile_onStartListening");

        Tile tile = getQsTile();
        if (tile != null) {
            if (isConnected()) {
                tile.setLabel(getString(R.string.home_activity_connected));
                tile.setState(Tile.STATE_ACTIVE);
                tile.updateTile();
            } else {
                tile.setLabel(getString(R.string.home_activity_disconnected));
                tile.setState(Tile.STATE_INACTIVE);
                tile.updateTile();
            }
        }
    }

    // 当 tile 不可见加时的回调
    public void onStopListening () {
        FirebaseUtil.sendEvent(getContext(), "Tile_onStopListening");
    }

    // 当 tile 点击时的回调
    public void onClick () {
        super.onClick();

        Tile tile = getQsTile();
        if (tile != null) {
            if (isConnected()) {
                FirebaseUtil.sendEvent(getContext(), "Tile_onClick", 0);
                LocalVpnService.IsRunning = false;
                tile.setLabel(getString(R.string.home_activity_disconnected));
                tile.setState(Tile.STATE_INACTIVE);
                tile.updateTile();
            } else {
                FirebaseUtil.sendEvent(getContext(), "Tile_onClick", 1);
                mConnectTask = new ConnectTask();
                mConnectTask.execute();
            }
        }
    }

    Context getContext() {
        return getApplicationContext();
    }

    class ConnectTask extends ModernAsyncTask<Void, Void, Void> {
        long connectingDuration = 0;

        @Override
        protected Void doInBackground(Void... voids) {
            SsServer server = OkHttp3Util.getCurrentServer(getContext());
            if (server != null) {
                String serverUrl = OkHttp3Util.convertServerToUrl(server);
                Intent intent = LocalVpnService.prepare(getContext());
                if (intent != null) {
                    Intent home = new Intent(getContext(), HomeActivity.class);
                    home.putExtra(HomeActivity.EXTRA_REQUEST_PERMISSION_NEEDED, true);
                    home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(home);
                    Utils.closeSystemDialogs(getContext());
                } else {
                    startVPNService(serverUrl);
                }
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            connectingDuration = System.currentTimeMillis();

            //Pre-App Proxy
            if (AppProxyManager.isLollipopOrAbove) {
                new AppProxyManager(getContext());
            }

            Tile tile = getQsTile();
            if (tile != null) {
                tile.setLabel(getString(R.string.home_activity_connecting));
                tile.updateTile();
                Log.i(TAG, "STATE::onPreExecute " + tile.getLabel());
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            connectingDuration = System.currentTimeMillis() - connectingDuration;
            FirebaseUtil.sendEvent(getContext(), "Tile_connect_duration", connectingDuration);

            Tile tile = getQsTile();
            if (tile != null) {
                tile.setLabel(getString(R.string.home_activity_connected));
                tile.setState(Tile.STATE_ACTIVE);
                tile.updateTile();
            }
        }
    }

    private void startVPNService(String proxyUrl) {
        if (!isValidUrl(proxyUrl)) {
            return;
        }

        FirebaseUtil.sendEvent(getContext(), "Tile_startVPNService", "url", proxyUrl);
//        mOnStatus.onLogReceived("starting...");
        LocalVpnService.ProxyUrl = proxyUrl;
        startService(new Intent(this, LocalVpnService.class));
    }

    boolean isValidUrl(String url) {
        try {
            if (url == null || url.isEmpty())
                return false;

            if (url.startsWith("ss://")) {//file path
                return true;
            } else { //url
                Uri uri = Uri.parse(url);
                if (!"http".equals(uri.getScheme()) && !"https".equals(uri.getScheme()))
                    return false;
                if (uri.getHost() == null)
                    return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean checkVpnConnected() {
        boolean res = false;

        try {
            Enumeration<NetworkInterface> niList = NetworkInterface.getNetworkInterfaces();
            if (niList != null) {
                for (NetworkInterface intf : Collections.list(niList)) {
                    if (!intf.isUp() || intf.getInterfaceAddresses().size() == 0) {
                        continue;
                    }
                    if ("tun0".equals(intf.getName()) || "ppp0".equals(intf.getName())) {
                        res = true;
                        break;
                    }
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }

        return res;
    }

    boolean isConnected() {
        return checkVpnConnected() && LocalVpnService.IsRunning;
    }
}