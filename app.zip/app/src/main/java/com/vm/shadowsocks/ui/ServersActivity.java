package com.vm.shadowsocks.ui;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.monkey.vpn.R;
import com.vm.shadowsocks.model.CategoryModel;
import com.vm.shadowsocks.model.ICategory;
import com.vm.shadowsocks.model.IModule;
import com.vm.shadowsocks.model.PreferenceHelper;
import com.vm.shadowsocks.model.SsServer;
import com.vm.shadowsocks.model.http.OkHttp3Util;
import com.vm.shadowsocks.util.android.os.ModernAsyncTask;
import com.vm.shadowsocks.view.CategoryViewHolder;
import com.vm.shadowsocks.view.FooterViewHolder;
import com.vm.shadowsocks.view.HeaderViewHolder;
import com.vm.shadowsocks.view.ModuleViewHolder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import util.com.bignerdranch.expandablerecyclerview.ChildViewHolder;
import util.com.bignerdranch.expandablerecyclerview.ExpandableRecyclerAdapter;
import util.com.bignerdranch.expandablerecyclerview.ExpandableRecyclerView;
import util.com.bignerdranch.expandablerecyclerview.ParentViewHolder;
import util.com.bignerdranch.expandablerecyclerview.TraverseListener;
import util.com.google.firebase.FirebaseUtil;

/**
 * Created by Luis
 * on 11/9/17.
 *
 */

public class ServersActivity extends Activity {
    public static final String TAG = "ServersActivity";

    public static final String MODULE_KEY_AD_FIRST = "module_key_ad_first";
    public static final int LANDSCAPE_GRID_COLUMN = 5;
    public static final int PORTRAIT_GRID_COLUMN = 1;
    private static final int HANDLE_UPDATE_USAGE = 1;

    private ExpandableRecyclerView mRecyclerView;
    private CategoryAdapter mRecyclerAdapter;
    private LoadUsagesTask mLoadUsagesTask;
    private int mGridColumn;

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (HANDLE_UPDATE_USAGE == msg.what) {
                SsServer server = (SsServer) mRecyclerAdapter.getChild(0, msg.arg1);
                server.signal = msg.arg2;
                mRecyclerAdapter.notifyChildChanged(0, msg.arg1);
            }
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.servers_activity);
        Log.i(TAG, "REQ::onCreate");
        FirebaseUtil.sendEvent(getContext(), TAG);

        mGridColumn = PORTRAIT_GRID_COLUMN;

        mRecyclerAdapter = new CategoryAdapter(parseModules(getContext()));
        mRecyclerAdapter.setExpandable(false);

        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(getLayoutManager());
        mRecyclerView.disableItemAnimator();
        mRecyclerView.setAdapter(mRecyclerAdapter);

        mLoadUsagesTask = new LoadUsagesTask();
        mLoadUsagesTask.execute();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mLoadUsagesTask != null) {
            mLoadUsagesTask.cancel(true);
        }
    }

    private Context getContext() {
        return getApplicationContext();
    }

    private Activity getActivity() {
        return this;
    }

    public LayoutInflater getInflater() {
        return getActivity().getLayoutInflater();
    }

    public View inflate(int resource, ViewGroup root) {
        return getInflater().inflate(resource, root);
    }

    public View inflate(int resource, ViewGroup root, boolean attachToRoot) {
        return getInflater().inflate(resource, root, attachToRoot);
    }

    private static ArrayList<ICategory> buildCategories(Context context) {
        ArrayList<ICategory> categories = new ArrayList<>();
        categories.add(new CategoryModel("CategoryModel 1"));
        return categories;
    }

    public static List<ICategory> parseModules(Context context) {
        Log.i(TAG, "parseModules");
        ArrayList<ICategory> categories = buildCategories(context);

        try {
            SsServer currentServer = OkHttp3Util.getCurrentServer(context);
            String currentKey = currentServer.getKey();

            List<SsServer> servers = OkHttp3Util.parseServers(context);
            for (SsServer server : servers) {
                ICategory category = categories.get(0);
                category.add(server);

                if (!TextUtils.isEmpty(currentKey)
                        && currentKey.equals(server.getKey())) {
                    server.checked = true;
                }
            }
        } catch (Throwable ignored) {
            ignored.printStackTrace();
        }

        return categories;
    }


    private RecyclerView.LayoutManager getLayoutManager() {
        GridLayoutManager res = new GridLayoutManager(getContext(), mGridColumn);

        res.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (mRecyclerAdapter.getItemViewType(position)) {
                    case CategoryAdapter.VIEW_TYPE_HEADER:
                    case CategoryAdapter.VIEW_TYPE_FOOTER:
                    case CategoryAdapter.VIEW_TYPE_PARENT_CATEGORY:
                    case CategoryAdapter.VIEW_TYPE_PARENT_AD:
                    case CategoryAdapter.VIEW_TYPE_CHILD_AD:
                        return mGridColumn;

                    case CategoryAdapter.VIEW_TYPE_CHILD_MODULE:
                    default:
                        return mGridColumn;
                }
            }
        });

        return res;
    }

    public class CategoryAdapter extends ExpandableRecyclerAdapter<ICategory, IModule, ParentViewHolder, ChildViewHolder> {
        private static final String KEY_VIEW_TYPE_HEADER = "view_type_header_key";
        private static final String KEY_VIEW_TYPE_FOOTER = "view_type_footer_key";

        private static final int VIEW_TYPE_PARENT_CATEGORY = 0;
        private static final int VIEW_TYPE_CHILD_MODULE = 1;
        private static final int VIEW_TYPE_PARENT_AD = 2;
        private static final int VIEW_TYPE_CHILD_AD = 3;

        private static final int VIEW_TYPE_HEADER = 4;
        private static final int VIEW_TYPE_FOOTER = 5;

        private View mHeaderView;
        private View mFooterView;

        CategoryAdapter(List<ICategory> categoryList) {
            super(categoryList);
        }

        void addCategory(ICategory category) {
            addCategory(getParentList().size(), category);
        }

        void addCategory(int position, ICategory category) {
            getParentList().add(position, category);
            notifyParentInserted(position);
        }

        @NonNull
        @Override
        public ParentViewHolder onCreateParentViewHolder(@NonNull ViewGroup parentViewGroup, int viewType) {
            if (VIEW_TYPE_HEADER == viewType && mHeaderView != null) {
                return new HeaderViewHolder(mHeaderView);
            } else if (VIEW_TYPE_FOOTER == viewType && mFooterView != null) {
                return new FooterViewHolder(mFooterView);
            }

            return new CategoryViewHolder(inflate(R.layout.servers_activity_category_view, parentViewGroup, false));
        }

        @NonNull
        @Override
        public ChildViewHolder onCreateChildViewHolder(@NonNull ViewGroup childViewGroup, int viewType) {
            if (VIEW_TYPE_CHILD_AD == viewType) {
                //return new AdViewHolder(inflate(R.layout.tool_fragment_list_ad, childViewGroup, false));
            }

            View view = inflate(R.layout.servers_activity_child_view, childViewGroup, false);
            return new ModuleViewHolder(view);
        }

        @Override
        public void onBindParentViewHolder(@NonNull ParentViewHolder parentViewHolder, int parentPosition, @NonNull ICategory parent) {
            if (parentViewHolder instanceof CategoryViewHolder) {
                CategoryViewHolder holder = (CategoryViewHolder) parentViewHolder;
                holder.bind(parent);
            } else if (parentViewHolder instanceof FooterViewHolder) {
                FooterViewHolder holder = (FooterViewHolder) parentViewHolder;
                //holder.bind();
            } else if (parentViewHolder instanceof HeaderViewHolder) {
            }
        }

        @Override
        public void onBindChildViewHolder(@NonNull ChildViewHolder childViewHolder, int parentPosition, int childPosition, @NonNull IModule child) {
            if (childViewHolder instanceof ModuleViewHolder) {
                ModuleViewHolder holder = (ModuleViewHolder) childViewHolder;
                holder.bind(child, childPosition, mOnClick, mOnLongClick);
            }
        }

        @Override
        public int getParentViewType(int parentPosition) {
            if (parentPosition == 0 && mHeaderView != null) {
                return VIEW_TYPE_HEADER;
            } else if (parentPosition == getParentCount() - 1 && mFooterView != null) {
                return VIEW_TYPE_FOOTER;
            }

            return VIEW_TYPE_PARENT_CATEGORY;
        }

        @Override
        public boolean isParentViewType(int viewType) {
            return VIEW_TYPE_PARENT_CATEGORY == viewType
                    || VIEW_TYPE_PARENT_AD == viewType
                    || VIEW_TYPE_HEADER == viewType
                    || VIEW_TYPE_FOOTER == viewType;
        }

        @Override
        public int getChildViewType(int parentPosition, int childPosition) {
            ICategory category = getParent(parentPosition);
            IModule module = getChild(parentPosition, childPosition);
            if (MODULE_KEY_AD_FIRST.equals(module.getKey())) {
                return VIEW_TYPE_CHILD_AD;
            }

            return VIEW_TYPE_CHILD_MODULE;
        }

        void setHeaderView(View mHeadView) {
            this.mHeaderView = mHeadView;
            addCategory(0, new CategoryModel(KEY_VIEW_TYPE_HEADER));
        }

        void setFooterView(View mFootView) {
            this.mFooterView = mFootView;
            addCategory(new CategoryModel(KEY_VIEW_TYPE_FOOTER));
        }

        int getParentCount() {
            return getParentList().size();
        }

        int getChildrenCount(int parentPosition) {
            return getParent(parentPosition).getChildList().size();
        }

        void traverse(TraverseListener listener) {
            for (int p = getParentCount() - 1; p >= 0; p--) {
                for (int c = getChildrenCount(p) - 1; c >= 0; c--) {
                    if (listener != null) {
                        listener.onTraverse(p, c);
                    }
                }
            }
        }

        private View.OnClickListener mOnClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "REQ::mOnClick ");
                if (v.getId() == R.id.root_view) {
                    if (v.getTag() instanceof Integer) {
                        int index = (int) v.getTag();
                        PreferenceHelper.get(getContext()).writeServerListValue(index);
                        setResult(HomeActivity.RESULT_OK);
                        finish();
                    }
                }
            }
        };

        private View.OnLongClickListener mOnLongClick = new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
//                IModule module = (IModule) v.getTag();
//                if (module == null) {
//                    return false;
//                }

                return false;
            }
        };
    }

    public static final String VPN_SERVER_API = "http://45.63.86.172/vpn_server";
    public static final String BALANCE_SERVER_API = "http://45.63.86.172/balance_server";
    public static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=utf-8");

    class LoadUsagesTask extends ModernAsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            loadUsages();
            return null;
        }
    }

    public void loadUsages() {
        try {
            Log.i(TAG, "BALANCE::loadUsages ");
            JSONArray jsonArray = new JSONArray();
            for (int i = 0; i < mRecyclerAdapter.getChildrenCount(0); i++) {
                IModule child = mRecyclerAdapter.getChild(0, i);
                jsonArray.put("45.63.86.172"); //child.getHost()
            }

            JSONObject postJson = new JSONObject();
            postJson.put("hosts", jsonArray);

            Request req = new Request.Builder()
                    .post(RequestBody.create(JSON_TYPE, postJson.toString()))
                    .url(BALANCE_SERVER_API)
                    .build();
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(10, TimeUnit.SECONDS)
                    .readTimeout(10, TimeUnit.SECONDS)
                    .build();

            Response response = client.newCall(req).execute();
            if (response.code() == HttpURLConnection.HTTP_OK) {
                //! http://blog.csdn.net/u014616515/article/details/52202942
                String body = response.body().string().trim();
                JSONObject json = new JSONObject(body);
                Log.i(TAG, "BALANCE::loadUsages json " + json);
                JSONArray array = json.getJSONArray("server_usage");
                for (int i = 0; i < array.length() && !mLoadUsagesTask.isCancelled(); i++) {
                    int usage = 0;
                    try {
                        JSONObject obj = (JSONObject) array.get(i);
                        usage = Integer.valueOf(obj.getString("usage"));
                    } catch (Throwable ignored) {
                    }

                    int signal = 100 - usage;
                    Message msg = mHandler.obtainMessage(HANDLE_UPDATE_USAGE);
                    msg.arg1 = i;
                    msg.arg2 = signal;
                    msg.sendToTarget();
                }
            }
        } catch (Exception e) {
            Log.i(TAG, "BALANCE::loadUsages Exception " + e);
            e.printStackTrace();
        }
    }
}
