package com.vm.shadowsocks.model.http;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.monkey.vpn.BuildConfig;
import com.monkey.vpn.R;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.vm.shadowsocks.firebase.remoteconfig.RemoteConfigHelper;
import com.vm.shadowsocks.model.PreferenceHelper;
import com.vm.shadowsocks.model.SsServer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by Luis on 11/5/17.
 *
 */

public class OkHttp3Util {

    private static final String TAG = "OkHttp3";
    public static final String KEY_CONFIG = "config";
    public static final String KEY_SERVER_LIST = "server_list";

    public static boolean testUrl(String url) throws IOException {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Response response = client.newCall(request).execute();
        String body = response.body().string();
        Log.i(TAG, "testUrl " + url + ", " + body);
        return body != null;
    }

    /**
     * convertServerToUrl
     *
     * @param server
     * @return ss://method:password@host:port
     */
    public static String convertServerToUrl(SsServer server) {
        return server.protocol + "://" + server.method + ":" + server.password + "@" + server.host + ":" + server.port;
    }

    public static int findCurrentServerIndex(Context context) {
        int index = PreferenceHelper.get(context).readServerListValue();
        List<SsServer> servers = parseServers(context);
        while (index >= servers.size()) {
            index--;
        }
        return index;
    }

    public static SsServer getCurrentServer(Context context) {
        SsServer res = null;

        try {
            List<SsServer> servers = parseServers(context);
            res = servers.get(findCurrentServerIndex(context));
        } catch (Throwable ignored) {
            ignored.printStackTrace();
        }

        return res;
    }

//    public static class PickServer {
//        public interface Callback {
//            void onPicking(int entryIndex);
//        }
//
//        private static SsServer pickBestServer(Context context, Callback callback) {
//            List<SsServer> servers = parseServers(context);
//            SsServer res = servers.get(0);
//
//            for (int i = 0; i < servers.size(); i++) {
//                SsServer s = servers.get(i);
//                try {
//                    Socket socket = new Socket(s.host, Integer.parseInt(s.port));
//                    if (callback != null) {
//                        callback.onPicking(i + 1);
//                    }
//
//                    if (socket.isConnected()) {
//                        res = s;
//                        break;
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//
//            return res;
//        }
//    }


    public static JsonArray parseServerListStrategy(Context context) {
        JsonArray serverListJsonArray;

        try {
            String jsonStr = RemoteConfigHelper.get().loadServerListJson();
            if (BuildConfig.DEBUG) Log.i(TAG, "parseServerListStrategy server " + jsonStr);
            JsonObject jsonObject = new JsonParser().parse(jsonStr).getAsJsonObject();
            serverListJsonArray = jsonObject.get(KEY_SERVER_LIST).getAsJsonArray();
        } catch (Throwable ignored) {
            if (BuildConfig.DEBUG) Log.i(TAG, "parseServerListStrategy Throwable " + ignored);
            String jsonStr = context.getString(R.string.ss_config_server_list_json);
            if (BuildConfig.DEBUG) Log.i(TAG, "parseServerListStrategy client " + jsonStr);
            JsonObject jsonObject = new JsonParser().parse(jsonStr).getAsJsonObject();
            serverListJsonArray = jsonObject.get(KEY_SERVER_LIST).getAsJsonArray();
        }

        return serverListJsonArray;
    }

    public static List<SsServer> parseServers(Context context) {
        List<SsServer> res = new ArrayList<>();

        try {
            JsonArray serverJsonArray = parseServerListStrategy(context);
            for (int i = 0; i < serverJsonArray.size(); i++) {
                JsonElement jsonElement = serverJsonArray.get(i);
                JsonObject jsonObject = jsonElement.getAsJsonObject();

                SsServer server = new SsServer();
                server.protocol = getJsonStr(jsonObject, SsServer.KEY_PROTOCOL);
                server.method = getJsonStr(jsonObject, SsServer.KEY_METHOD);
                server.password = getJsonStr(jsonObject, SsServer.KEY_PASSWORD);
                server.host = getJsonStr(jsonObject, SsServer.KEY_HOST);
                server.port = getJsonStr(jsonObject, SsServer.KEY_PORT);
                server.encode = getJsonStr(jsonObject, SsServer.KEY_ENCODE);
                server.country = getJsonStr(jsonObject, SsServer.KEY_COUNTRY);
                server.district = getJsonStr(jsonObject, SsServer.KEY_DISTRICT);
                server.state = getJsonStr(jsonObject, SsServer.KEY_STATE);

                if (TextUtils.isEmpty(server.state)
                        || SsServer.STATE_ENABLED.equals(server.state)) {
                    res.add(server);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return res;
    }

    private static String getJsonStr(JsonObject jsonObject, String key) {
        String res = null;

        try {
            res = jsonObject.get(key).getAsString();
        } catch (Throwable ignored) {
        }

        return res;
    }
}
