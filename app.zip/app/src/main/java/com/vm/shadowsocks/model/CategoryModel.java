package com.vm.shadowsocks.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/4/6 0006.
 */

public class CategoryModel implements ICategory {

    private String mName;
    private List<IModule> mModules;

    public CategoryModel(String name) {
        this(name, new ArrayList<IModule>());
    }

    public CategoryModel(String name, List<IModule> modules) {
        mName = name;
        mModules = modules;
    }

    @Override
    public List<IModule> getChildList() {
        return mModules;
    }

    @Override
    public boolean isInitiallyExpanded() {
        return true;
    }

    public String getName() {
        return mName;
    }

    public void add(IModule module) {
        mModules.add(module);
    }

    public void add(int location, IModule module) {
        mModules.add(location, module);
    }

    @Override
    public int getChildrenCount() {
        return mModules.size();
    }
}
