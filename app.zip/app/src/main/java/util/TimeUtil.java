package util;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TimeUtil {
    private static final String TAG = TimeUtil.class.getSimpleName();
    public static final String SP_NAME = "sp_name_" + TAG;

    public static final long MILLISECOND = 100L;
    public static final long SECOND = 10L * MILLISECOND;
    public static final long MINUTE = 60L * SECOND;
    public static final long HOUR = 60L * MINUTE;
    public static final long DAY = 24L * HOUR;
    public static final long WEEK = 7L * DAY;
    public static final long MONTH = 30L * DAY;

    public static final int TIME_LIMIT_5_MINUTE = 5 * 60 * 1000;

    public static final String LAST_TIME_FOR_CLEAN_SHORTCUT = "clean_shortcut_clean_time";
    public static final String LAST_TIME_FOR_BOOST_SHORTCUT = "boost_shortcut_clean_time";
    public static final String LAST_TIME_FOR_BATTERY_SAVE = "battery_save_clean_time";

    public static final long FOOLS_START_TIME = format2Long2("2017-04-01 00:00");
    public static final long FOOLS_END_TIME = format2Long2("2017-04-02 00:00");

    public static final long FOOL_PREPARE_START_TIME = format2Long2("2017-03-20 00:00");
    public static final long FOOL_PREPARE_END_TIME = format2Long2("2017-03-31 23:59");

    public static boolean isTimeUp(Context context, String key, long timeLimit) {
        SharedPreferences sp = context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        long current = System.currentTimeMillis();
        long last = sp.getLong(key, 0);
        long delta = current - last;
        boolean res = (delta > timeLimit);
        return res;
    }

    public static void resetTimeUp(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        long current = System.currentTimeMillis();
        sp.edit().putLong(key, current).commit();
    }

    public static void setTimeUp(Context context, String key, long time) {
        SharedPreferences sp = context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
        sp.edit().putLong(key, time).commit();
    }

    public static boolean checkTimeUp(Context context, String key, long timeLimit) {
        if(isTimeUp(context, key, timeLimit)) {
            resetTimeUp(context, key);
            return true;
        } else {
            return false;
        }
    }


    public static boolean checkCountUp(Context context, String key, long countLimit) {
        if(countLimit != 0) {
            SharedPreferences sp = context.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
            long last = sp.getLong(key, 0);
            long current = last + 1;
            sp.edit().putLong(key, current).commit();

            Log.i(TAG, "FB::checkCountUp " + current+"%"+countLimit + " = " + key);
            if (current % countLimit == 0) {
                return true;
            }
        }
        return false;
    }

    public static long format2Long(String string) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            java.util.Date date = dateFormat.parse(string);

            return date.getTime();

        } catch (ParseException e) {
            //LogUtil.w(TAG, e);
        }

        return -1;

    }

    public static long format2Long2(String string) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            java.util.Date date = dateFormat.parse(string);

            return date.getTime();

        } catch (ParseException e) {
            //LogUtil.w(TAG, e);
        }

        return -1;

    }

    public static boolean isInFoolsRange(long currentTime) {
        return FOOLS_START_TIME <= currentTime
                && FOOLS_END_TIME >= currentTime;
    }

    public static boolean isInFoolPrepareRange(long currentTime) {
        Log.i(TAG, "isInFoolPrepareRange " + FOOL_PREPARE_START_TIME + " < " + currentTime + " < " + FOOL_PREPARE_END_TIME);
        return FOOL_PREPARE_START_TIME <= currentTime
                && FOOL_PREPARE_END_TIME >= currentTime;
    }
}
