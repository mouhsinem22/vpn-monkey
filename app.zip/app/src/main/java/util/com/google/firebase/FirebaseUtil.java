package util.com.google.firebase;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.monkey.vpn.BuildConfig;
import com.google.firebase.perf.FirebasePerformance;
import com.google.firebase.perf.metrics.Trace;
import com.qiniu.android.netdiag.TcpPing;

import util.android.content.ResourceUtil;
import util.com.qiniu.android.netdiag.PingUtil;

/**
 * Created by Administrator
 * on 2017/2/6 0006.
 */

public class FirebaseUtil {
    public static final String TAG = "FirebaseUtil";

    public static boolean DEBUG = BuildConfig.DEBUG;

    public static void sendEvent(Context context, String key, Bundle bundle) {
        try {
            if (DEBUG) Log.i(TAG, "sendEvent " + key + ", " + bundle);
            FirebaseAnalytics.getInstance(context).logEvent(key, bundle);
        } catch (Throwable ignored) {
        }
    }

    public static void sendEvent(Context context, String key, String type, String value) {
        sendEvent(context, key, buildBundle(type, value));
    }

    public static void sendEvent(Context context, String key, String type, long value) {
        sendEvent(context, key, buildBundle(type, value));
    }

    public static void sendEvent(Context context, String key, long value) {
        sendEvent(context, key, buildBundle(FirebaseAnalytics.Param.VALUE, value));
    }

    public static void sendEvent(Context context, String key) {
        sendEvent(context, key, buildBundle(FirebaseAnalytics.Param.VALUE, -1));
    }

    public static void sendEventViewState(Context context, String key, long state) {
        sendEvent(context, key, buildBundle("view_state", state));
    }

    public static void sendEventViewClick(Context context, String key) {
        sendEvent(context, key, buildBundle("view_click", 1));
    }

    public static Bundle buildBundle(String key, String values) {
        Bundle params = new Bundle();
        params.putString(key, values);
        return params;
    }

    public static Bundle buildBundle(String key, long values) {
        Bundle params = new Bundle();
        params.putLong(key, values);
        return params;
    }

    public static void startTcpPingTrace(final Context context, final String key, final String host) {
        final Trace myTrace = FirebasePerformance.getInstance().newTrace(key);
        PingUtil.startTcpPing(host, new PingUtil.OnPreExecute() {
            @Override
            public void onPreExecute() {
                myTrace.start();
            }
        }, new PingUtil.OnPostExecute() {
            @Override
            public void onPostExecute(TcpPing.Result r) {
                myTrace.putAttribute("ip", r.ip);
                myTrace.putAttribute("code", "" + r.code);
                myTrace.putAttribute("count", "" + r.count);
                myTrace.putAttribute("avgTime", "" + r.avgTime);
                myTrace.putAttribute("avgTime", "" + r.avgTime);
                myTrace.putAttribute("country", ResourceUtil.getCountry(context));
                myTrace.stop();
            }
        });
    }
}
