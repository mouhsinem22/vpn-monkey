package util.com.qiniu.android.netdiag;

import android.util.Log;

import com.qiniu.android.netdiag.Output;
import com.qiniu.android.netdiag.TcpPing;

/**
 * Created by Administrator
 * on 2018/6/26 0026.
 */

public class PingUtil {
    public static final String TAG = "PingUtil";

    public interface OnPreExecute {
        public void onPreExecute();
    }

    public interface OnPostExecute {
        public void onPostExecute(TcpPing.Result r);
    }

    public static void startTcpPing(String host, int port, int count, Output output, TcpPing.Callback callback) {
        try {
            TcpPing.start(host, port, count, output, callback);
        } catch (Throwable ignored) {
            ignored.printStackTrace();
        }
    }

    public static void startTcpPing(final String host, final TcpPing.Callback callback) {
        Output output = new Output() {
            @Override
            public void write(String line) {
                Log.i(TAG, "TcpPing::write    " + host + ", " + line);
            }
        };
        int port = 80;
        int count = 1;

        startTcpPing(host, port, count, output, callback);
    }

    public static void startTcpPing(final String host, final OnPreExecute preExecute, final OnPostExecute postExecute) {
        if (preExecute != null) {
            preExecute.onPreExecute();
        }

        startTcpPing(host, new TcpPing.Callback() {
            @Override
            public void complete(TcpPing.Result r) {
                printTcpPingResult(host, r);
                if (postExecute != null) {
                    postExecute.onPostExecute(r);
                }
            }
        });
    }

    public static void startTcpPing(final String host) {
        startTcpPing(host, null, null);
    }

    public static void printTcpPingResult(String host, TcpPing.Result r) {
        Log.i(TAG, "TcpPing::complete "
                + host
                + ",code [" + r.code + "]"
                + ",ip " + r.ip
                + ",count " + r.count
                + ",dropped " + r.dropped
                + ",avgTime " + r.avgTime
                + ",maxTime " + r.maxTime
                + ",minTime " + r.minTime
                + ",stddevTime " + r.stddevTime
        );
    }

}
