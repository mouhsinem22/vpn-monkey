package util.com.bignerdranch.expandablerecyclerview;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;

/**
 * Created by Administrator on 2017/4/6 0006.
 */

public class ExpandableRecyclerView extends RecyclerView {
    private static final String TAG = ExpandableRecyclerView.class.getSimpleName();

    public ExpandableRecyclerView(Context context) {
        super(context);
        init();
    }

    public ExpandableRecyclerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ExpandableRecyclerView(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    void init() {
        Log.i(TAG, "ERV::init");
        //http://blog.csdn.net/rui574081323/article/details/52461608
//        ((SimpleItemAnimator) getItemAnimator()).setSupportsChangeAnimations(false);
        //http://stackoverflow.com/questions/29873859/how-to-implement-itemanimator-of-recyclerview-to-disable-the-animation-of-notify
//        ((DefaultItemAnimator) getItemAnimator()).setSupportsChangeAnimations(false);
    }

    public void disableItemAnimator() {
        setItemAnimator(null);
    }
}
