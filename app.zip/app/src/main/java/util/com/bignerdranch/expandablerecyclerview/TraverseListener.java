package util.com.bignerdranch.expandablerecyclerview;

/**
 * Created by Administrator on 2017/4/12 0012.
 */

public interface TraverseListener {
    void onTraverse(int parentPosition, int childPosition);
}
