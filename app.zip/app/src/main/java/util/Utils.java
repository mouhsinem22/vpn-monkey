/*
 * Copyright (C) 2012 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Build.VERSION_CODES;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;

import util.android.content.ContextUtil;

//import com.manager.config.SkinConfig;
//
//import base.util.Log;
//import base.util.PackageUtil;
//import base.util.PreferenceHelper;
//import base.util.android.content.ContextUtil;
//import imoblife.toolbox.full.R;

/**
 * Class containing some static utility methods.
 *
 android.os.Build.VERSION_CODES
 public static final int BASE = 1;
 public static final int BASE_1_1 = 2;
 public static final int CUPCAKE = 3;
 public static final int DONUT = 4;
 public static final int ECLAIR = 5;
 public static final int ECLAIR_0_1 = 6;
 public static final int ECLAIR_MR1 = 7;
 public static final int FROYO = 8;
 public static final int GINGERBREAD = 9;
 public static final int GINGERBREAD_MR1 = 10;
 public static final int HONEYCOMB = 11;
 public static final int HONEYCOMB_MR1 = 12;
 public static final int HONEYCOMB_MR2 = 13;
 public static final int ICE_CREAM_SANDWICH = 14;
 public static final int ICE_CREAM_SANDWICH_MR1 = 15;
 public static final int JELLY_BEAN = 16;
 public static final int JELLY_BEAN_MR1 = 17;
 public static final int JELLY_BEAN_MR2 = 18;
 public static final int KITKAT = 19;
 public static final int KITKAT_WATCH = 20;
 public static final int LOLLIPOP = 21;
 *
 */
public class Utils {
	private static final String TAG = Utils.class.getSimpleName();

	private Utils() {
	};

	@TargetApi(VERSION_CODES.HONEYCOMB)
	public static void enableStrictMode() {
		if (Utils.hasGingerbread()) {
			StrictMode.ThreadPolicy.Builder threadPolicyBuilder = new StrictMode.ThreadPolicy.Builder()
					.detectAll().penaltyLog();
			StrictMode.VmPolicy.Builder vmPolicyBuilder = new StrictMode.VmPolicy.Builder()
					.detectAll().penaltyLog();

			if (Utils.hasHoneycomb()) {
				threadPolicyBuilder.penaltyFlashScreen();
				// vmPolicyBuilder
				// .setClassInstanceLimit(ImageGridActivity.class, 1)
				// .setClassInstanceLimit(ImageDetailActivity.class, 1);
			}
			StrictMode.setThreadPolicy(threadPolicyBuilder.build());
			StrictMode.setVmPolicy(vmPolicyBuilder.build());
		}
	}

	public static boolean hasFroyo() {
		// Can use static final constants like FROYO, declared in later versions
		// of the OS since they are inlined at compile time. This is guaranteed
		// behavior.
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO;
	}

	public static boolean hasGingerbread() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD;
	}

	public static boolean hasHoneycomb() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB;
	}

	public static boolean hasHoneycombMR1() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR1;
	}

	public static boolean hasJellyBean() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN;
	}

	public static boolean hasJellyBeanMR1() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1;
	}

	public static boolean hasJellyBeanMR2() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2;
	}

	public static boolean hasKitKat() {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
	}

	public static boolean hasOreoSdk26() {
		return Build.VERSION.SDK_INT >= 26; //Build.VERSION_CODES.OREO;
	}

	public static void closeSystemDialogs(Context context) {
		try {
			if (VERSION.SDK_INT >= 14) {
				context.sendBroadcast(new Intent(
						Intent.ACTION_CLOSE_SYSTEM_DIALOGS));
			}
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

//	public static void sendFeedback(Context context, String email) {
//		ContextUtil.sendEmail(
//				context,
//				email,
//				"All-In-One Toolbox Feedback",
//				buildDebugInfo(context));
//	}

//	public static String buildDebugInfo(Context context) {
//		return "\n\n-----------------------------\n"
//				+ "Manufacturer: "  + Build.MANUFACTURER + "\n"
//				+ "Model: " + Build.MODEL + "\n"
//				+ "OS Version: " + VERSION.RELEASE + "\n"
//				+ "ROM: " + Build.DISPLAY + "\n"
//				+ "Screen: " + context.getString(R.string.screen_mode) + "\n"
//				+ "Root: " + PreferenceHelper.isRooted(context) + "\n"
//				+ "Theme: " + SkinConfig.getSkinName(context) + "\n"
//                + "Application Name: " + StringUtil.getAppName(context) + "\n"
//                + "Package Name: " + context.getPackageName() + "\n"
//                + "Version Name: " + PackageUtil.getVersionName(context) + "(" + PackageUtil.getVersionCode(context) + ")" + "\n"
//				+ "Language: " + PreferenceHelper.getLanguageValue(context) + "\n"
//                + "\n-----------------------------\n\n";
//	}

	/**
	 * MX3有两种型号：MX351和MX353
	 * @return
	 */
	public static boolean isMeizu_MX3()
	{
		boolean isMx3 = false;
		String build = Build.BRAND;
		String model = android.os.Build.MODEL;
		if(!TextUtils.isEmpty(build) && !TextUtils.isEmpty(model)){
			if(build.toLowerCase().equals("meizu") && (model.toLowerCase().equals("m351")
					|| model.toLowerCase().equals("m353"))){
				isMx3 = true;
			}
		}
		return isMx3;
	}

	public static boolean isMeizu_MX2()
	{

		boolean isMx2 = false;
		String build = Build.BRAND;
		String model = android.os.Build.MODEL;
		if(!TextUtils.isEmpty(build) && !TextUtils.isEmpty(model)){
			if(build.toLowerCase().equals("meizu") && (model.toLowerCase().equals("m040"))){
				isMx2 = true;
			}
		}
		return isMx2;
	}

}


