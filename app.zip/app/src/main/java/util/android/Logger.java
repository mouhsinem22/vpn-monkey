package util.android;

import android.os.Debug;

/**
 * 扩展功能的Log，可以实现点击定位，{@link Debug#DEG}控制log输出 <br />
 * <br />
 * 1.只有一个参数的函数，它的tag使用默认{@link #TAG}. 而两个参数的可以自定义tag。<br />
 * 2.在eclipse的LogCat中输出时，双击[PLACE]开头的那一行就可以定位到发出log的那一行代码.<br />
 * 3.[MESSAGE]开头的那一行就是log消息。 <br />
 * <b style="color:red;">正式版发布时，一定要把{@link Logger#DEG}设置为false</b> </br>
 */
public class Logger {

    /**
     * log总开关   svn DEG=false 请勿修改!!!
     */
    private static boolean DEG = false;

    public static boolean isDEG() {
        return DEG;
    }

    public static void setDEG(boolean dEG) {
        DEG = dEG;
    }

    private static final String TAG = "Toolbox";
    private static final String HEAD_MESSAGE = "[MESSAGE] ";
    private static final String HEAD_PLACE = "[PLACE] ";
    private static final String BLANK_LINE = "\n ";

    private static final int STACK_LAYER = 3;

    public static void i(String msg) {
        if (DEG) android.util.Log.i(TAG, getFormatedMsg(null, msg));
    }

    public static void e(String msg) {
        if (DEG) android.util.Log.e(TAG, getFormatedMsg(null, msg));
    }

    public static void d(String msg) {
        if (DEG) android.util.Log.d(TAG, getFormatedMsg(null, msg));
    }

    public static void v(String msg) {
        if (DEG) android.util.Log.v(TAG, getFormatedMsg(null, msg));
    }

    public static void w(String msg) {
        if (DEG) android.util.Log.w(TAG, getFormatedMsg(null, msg));
    }

    public static void i(String subTag, String msg) {
        if (DEG) android.util.Log.i(TAG, getFormatedMsg(subTag, msg));
    }

    public static void e(String subTag, String msg) {
        if (DEG) android.util.Log.e(TAG, getFormatedMsg(subTag, msg));
    }

    public static void d(String subTag, String msg) {
        if (DEG) android.util.Log.d(TAG, getFormatedMsg(subTag, msg));
    }

    public static void v(String subTag, String msg) {
        if (DEG) android.util.Log.v(TAG, getFormatedMsg(subTag, msg));
    }

    public static void w(String subTag, String msg) {
        if (DEG) android.util.Log.w(TAG, getFormatedMsg(subTag, msg));
    }

    /**
     * 专用做打印异常信息的日志
     */
    public static void exceptionPrint(String subTag, Exception e) {
        if (DEG && e != null) android.util.Log.e(TAG, getFormatedMsg(subTag, e.getMessage()));
    }

    /**
     * 专用做打印异常信息的日志
     */
    public static void exceptionPrint(Exception e) {
        if (DEG && e != null) android.util.Log.e(TAG, getFormatedMsg(null, e.getMessage()));
    }

    private static String getFormatedMsg(String subTag, String msg) {
        if (subTag == null) {
            return HEAD_PLACE + getPlace() + HEAD_MESSAGE + msg + BLANK_LINE;
        } else {
            return HEAD_PLACE + getPlace() + "[" + subTag + "]" + msg;
        }
    }

    private static String getPlace() {
        StackTraceElement[] stacks = new Throwable()
                .getStackTrace();
        if (stacks.length <= STACK_LAYER) {
            return "";
        }
        return new StringBuilder().append("at ")
                .append(stacks[STACK_LAYER].getClassName()).append(".")
                .append(stacks[STACK_LAYER].getMethodName()).append("(")
                .append(stacks[STACK_LAYER].getFileName()).append(":")
                .append(stacks[STACK_LAYER].getLineNumber()).append(")\n")
                .toString();
    }
}