package util.android.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.text.format.Formatter;
import android.util.Log;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

public class NetworkUtil {
	public static final String TAG = NetworkUtil.class.getSimpleName();

	public static WifiManager WM(Context context) {
		return (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
	}

	public static ConnectivityManager CM(Context context) {
		return (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
	}

	public static String getWifiNetworkId(Context context) {
		String result = WM(context).getConnectionInfo().getSSID();
		return (result != null) ? result : "";
	}

	public static String getWifiMacAddress(Context context) {
		String result = WM(context).getConnectionInfo().getBSSID();
		return (result != null) ? result : "";
	}

	//andoid 4.4: java.lang.UnsatisfiedLinkError: Couldn't load macAddr from loader dalvik.system.PathClassLoader
	//	public static String getJniWifiMacAddress(Context context) {
	//		String result = "";
	//		try {
	//			if (isWifiConnected(context)) {
	//				result = MacAddr.getMacAddr(context);
	//			}
	//		} catch (Exception e) {
	//			LogUtil.w(TAG, e);
	//		}
	//		return result.toUpperCase();
	//	}

	public static String getWifiIpAddress(Context context) {
		int ip = WM(context).getConnectionInfo().getIpAddress();
		String result = Formatter.formatIpAddress(ip);
		return (result != null) ? result : "";
	}

	public static String getWifiGateway(Context context) {
		int gateway = WM(context).getDhcpInfo().gateway;
		String result = Formatter.formatIpAddress(gateway);
		return (result != null) ? result : "";
	}

	public static String getWifiLinkSpeed(Context context) {
		String result = WM(context).getConnectionInfo().getLinkSpeed() + "mbps";
		return (result != null) ? result : "";
	}

	public static int asu2dbm(int asu) {
		return -113 + 2 * asu;
	}

//	public static String getWifiSignalStrength(Context context) {
//		int rssi = WM(context).getConnectionInfo().getRssi();
//		String result = rssi + " dBm";
//		if (rssi >= asu2dbm(30) && rssi != asu2dbm(99)) {
//			result += "(" + context.getString(R.string.network_signalgood)
//					+ ")";
//		} else if (gsmAsu >= asu2dbm(20) && gsmAsu < asu2dbm(30)) {
//			result += "(" + context.getString(R.string.network_signalaverage)
//					+ ")";
//		} else if (gsmAsu < asu2dbm(20)) {
//			result += "(" + context.getString(R.string.network_signalweak)
//					+ ")";
//		}
//		return (result != null) ? result : "";
//	}

	public static boolean isWifiConnected(Context context) {
		android.net.NetworkInfo.State state = CM(context).getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
		return (state == android.net.NetworkInfo.State.CONNECTED);
	}

	public static String getLocalIpAddress(Context context) {
		String result = "";
		try {
			for (Enumeration enumIf = NetworkInterface.getNetworkInterfaces(); enumIf
					.hasMoreElements();) {
				NetworkInterface ifs = (NetworkInterface) enumIf.nextElement();
				for (Enumeration enumIp = ifs.getInetAddresses(); enumIp
						.hasMoreElements();) {
					InetAddress ips = (InetAddress) enumIp.nextElement();
					if (!ips.isLoopbackAddress()) {
						result = ips.getHostAddress().toString();
					}
				}
			}
		} catch (SocketException e) {
			Log.d(null, e.getMessage());
		}
		return result;
	}

//	public static String getNetworkType(Context context) {
//		String result = "";
//		switch (TelephonyUtil.TM(context).getNetworkType()) {
//		case 7:
//			result = "1xRTT";
//			break;
//		case 4:
//			result = "CDMA";
//			break;
//		case 2:
//			result = "EDGE";
//			break;
//		case 14:
//			result = "eHRPD";
//			break;
//		case 5:
//			result = "EVDO rev. 0";
//			break;
//		case 6:
//			result = "EVDO rev. A";
//			break;
//		case 12:
//			result = "EVDO rev. B";
//			break;
//		case 1:
//			result = "GPRS";
//			break;
//		case 8:
//			result = "HSDPA";
//			break;
//		case 10:
//			result = "HSPA";
//			break;
//		case 15:
//			result = "HSPA+";
//			break;
//		case 9:
//			result = "HSUPA";
//			break;
//		case 11:
//			result = "iDen";
//			break;
//		case 13:
//			result = "LTE";
//			break;
//		case 3:
//			result = "UMTS";
//			break;
//		case 0:
//		default:
//			break;
//		}
//		return result;
//	}

	public static String gsmSignal = null;
	public static int gsmAsu = 0;
	public static int gsmDbm = 0;

//	public static String getGsmSignalStrength(final Context context) {
//		PhoneStateListener listener = new PhoneStateListener() {
//			public void onSignalStrengthsChanged(SignalStrength signalStrength) {
//				super.onSignalStrengthsChanged(signalStrength);
//				gsmAsu = signalStrength.getGsmSignalStrength();
//				gsmDbm = (-113 + 2 * gsmAsu);
//				gsmSignal = gsmDbm + " dBm";
//				if (gsmAsu >= 30 && gsmAsu != 99) {
//					gsmSignal += "("
//							+ context.getString(R.string.network_signalgood)
//							+ ")";
//				} else if (gsmAsu >= 20 && gsmAsu < 30) {
//					gsmSignal += "("
//							+ context.getString(R.string.network_signalaverage)
//							+ ")";
//				} else if (gsmAsu < 20) {
//					gsmSignal += "("
//							+ context.getString(R.string.network_signalweak)
//							+ ")";
//				}
//			}
//		};
//		TelephonyUtil.TM(context).listen(listener,
//				PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
//		String result = gsmSignal;
//		return (result != null) ? result : "";
//	}

	/** Anything worse than or equal to this will show 0 bars. */
	private static final int MIN_RSSI = -100;

	/** Anything better than or equal to this will show the max bars. */
	private static final int MAX_RSSI = -55;

	public static int calculateWifiSignalPercent(Context context) {
		int rssi = WM(context).getConnectionInfo().getRssi();
		if (rssi <= MIN_RSSI) {
			return 0;
		} else if (rssi >= MAX_RSSI) {
			return 100;
		} else {
			float inputRange = (MAX_RSSI - MIN_RSSI);
			float outputRange = (100 - 1);
			return (int) ((float) (rssi - MIN_RSSI) * outputRange / inputRange);
		}
	}

	/**
	 * http://grepcode.com/file/repository.grepcode.com/java/ext/com.google.android/android/4.1.1_r1/android/net/wifi/WifiManager.java#WifiManager.0RSSI_LEVELS
	 * @param context
	 * @return
	 */
	public static int calculateWifiSignalLevel(Context context) {
		/*public static */final int RSSI_LEVELS = 5;
		int numLevels = RSSI_LEVELS;
		int rssi = WM(context).getConnectionInfo().getRssi();
		if (rssi <= MIN_RSSI) {
			return 0;
		} else if (rssi >= MAX_RSSI) {
			return numLevels - 1;
		} else {
			float inputRange = (MAX_RSSI - MIN_RSSI);
			float outputRange = (numLevels - 1);
			return (int) ((float) (rssi - MIN_RSSI) * outputRange / inputRange);
		}
	}

	public static final int SIGNAL_STRENGTH_NONE_OR_UNKNOWN = 0;
	public static final int SIGNAL_STRENGTH_POOR = 1;
	public static final int SIGNAL_STRENGTH_MODERATE = 2;
	public static final int SIGNAL_STRENGTH_GOOD = 3;
	public static final int SIGNAL_STRENGTH_GREAT = 4;
	public static final int NUM_SIGNAL_STRENGTH_BINS = 5;
	public static final String[] SIGNAL_STRENGTH_NAMES = { "none", "poor",
			"moderate", "good", "great" };

	private static final int GSM_SIGNAL_STRENGTH_GREAT = 12;
	private static final int GSM_SIGNAL_STRENGTH_GOOD = 8;
	private static final int GSM_SIGNAL_STRENGTH_MODERATE = 8;

	public static int getGsmSignalPercent(Context context) {
		int level = SIGNAL_STRENGTH_NONE_OR_UNKNOWN;
		if (gsmAsu <= 2 || gsmAsu == 99) {
			level = SIGNAL_STRENGTH_NONE_OR_UNKNOWN;
		} else {
			level = gsmAsu * 100 / 31;
		}
		return level;
	}

	/**
	 * Get gsm as level 0..4
	 *
	 * @hide
	 */
	public static int getGsmLevel() {
		int level = SIGNAL_STRENGTH_NONE_OR_UNKNOWN;

		// ASU ranges from 0 to 31 - TS 27.007 Sec 8.5
		// asu = 0 (-113dB or less) is very weak
		// signal, its better to show 0 bars to the user in such cases.
		// asu = 99 is a special case, where the signal strength is unknown.
		//		int asu = getGsmSignalStrength();
		int asu = gsmAsu;
		if (asu <= 2 || asu == 99)
			level = SIGNAL_STRENGTH_NONE_OR_UNKNOWN;
		else if (asu >= 12)
			level = SIGNAL_STRENGTH_GREAT;
		else if (asu >= 8)
			level = SIGNAL_STRENGTH_GOOD;
		else if (asu >= 5)
			level = SIGNAL_STRENGTH_MODERATE;
		else
			level = SIGNAL_STRENGTH_POOR;
		return level;
	}

//	public static boolean isNetworkAvailable(Context context) {
//
//		ConnectivityManager conmgr = (ConnectivityManager) context
//				.getSystemService(Context.CONNECTIVITY_SERVICE);
//		if (conmgr == null) {
//			return false;
//		}
//
//		// 修改解决判断网络时的崩溃
//		// mobile 3G Data Network
//		NetworkInfo net3g = conmgr.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
//		if (net3g != null) {
//			NetworkInfo.State mobile = net3g.getState();// 显示3G网络连接状态
//			if (mobile == NetworkInfo.State.CONNECTED || mobile == NetworkInfo.State.CONNECTING)
//				return true;
//		}
//		NetworkInfo netwifi = conmgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
//		if (netwifi != null) {
//			NetworkInfo.State wifi = netwifi.getState(); // wifi
//			// 如果3G网络和wifi网络都未连接，且不是处于正在连接状态 则进入Network Setting界面 由用户配置网络连接
//			if (wifi == NetworkInfo.State.CONNECTED || wifi == NetworkInfo.State.CONNECTING)
//				return true;
//		}
//
//		return false;
//	}
}
