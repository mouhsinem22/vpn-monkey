package util.android.content;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.regex.Pattern;

import org.xmlpull.v1.XmlPullParser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.AssetManager;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.util.Log;


public class PackageUtil {
	public static final String TAG = PackageUtil.class.getSimpleName();

	public static final long SECOND = 1L * 1000L;
	public static final long MINUTE = 60L * SECOND;
	public static final long HOUR = 60L * MINUTE;
	public static final long DAY = 24L * HOUR;
	public static final long WEEK = 7L * DAY;
	public static final long MONTH = 30L * DAY;

    private static Field x;

	public static ApplicationInfo loadAppInfo(Context context, String pkgName) {
		try {
			return context.getPackageManager().getApplicationInfo(pkgName, 1);
		} catch (Exception e) {
			Log.w(TAG, e);
			return null;
		}
	}

	public static PackageInfo loadApkInfo(Context context, String uri) {
		try {
			return context.getPackageManager().getPackageArchiveInfo(uri,
					PackageManager.GET_ACTIVITIES);
		} catch (Exception e) {
			Log.w(TAG, e);
			return null;
		}
	}

	public static String loadApkPkgName(Context context, String uri) {
		try {
			return loadApkInfo(context, uri).packageName;
		} catch (Exception e) {
			Log.w(TAG, e);
			return "";
		}
	}

	public static Context createPackageContext(Context context, String pkgName) {
		Context result = null;
		try {
			result = context.createPackageContext(pkgName,
					Context.CONTEXT_IGNORE_SECURITY
							| Context.CONTEXT_INCLUDE_CODE);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return result;
	}

	public static boolean isApkInstalled(Context context, String apkUri) {
		boolean result = false;
		try {
			result = isPackageInstalled(context,
					PackageUtil.getAppInfo(context, apkUri).packageName);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return result;
	}

	public static boolean isPackageInstalled(Context context, String pkgName) {
		boolean result = false;
		try {
			if (!isNameEmpty(pkgName)) {
				PackageManager pm = context.getPackageManager();
				pm.getPackageInfo(pkgName, PackageManager.GET_META_DATA);
				result = true;
			}
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return result;
	}

	public static boolean isPackageVersionInstalled(Context context,
			String pkgName, int versionCode) {
		boolean result = false;
		try {
			if (!isNameEmpty(pkgName)) {
				PackageManager pm = context.getPackageManager();
				PackageInfo info = pm.getPackageInfo(pkgName,
						PackageManager.GET_META_DATA);

				if (versionCode == info.versionCode) {
					result = true;
				}
			}
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return result;
	}

	private static boolean isNameEmpty(String name) {
		if (null == name || "".equals(name)) {
			return true;
		} else {
			return false;
		}
	}

	// public static boolean checkPackageInstalled(Context mContext, String
	// pkgName) {
	// try {
	// mContext.createPackageContext(pkgName,
	// Context.CONTEXT_IGNORE_SECURITY
	// | Context.CONTEXT_INCLUDE_CODE);
	// return true;
	// } catch (Exception e) {
	// return false;
	// }
	// }

	// ///////////////////////////////////////////////////////////////////////////////////////////////////////

	private static final String SCHEME = "package";
//	private static final String APP_PKG_NAME_21 = "com.android.settings.ApplicationPkgName";
//	private static final String APP_PKG_NAME_22 = "pkg";
//	private static final String APP_DETAILS_PACKAGE_NAME = "com.android.settings";
//	private static final String APP_DETAILS_CLASS_NAME = "com.android.settings.InstalledAppDetails";

	public static void showAppDetails(Context context, String pkgName) {
		try {
			Intent intent = new Intent();
			final int apiLevel = Build.VERSION.SDK_INT;

			// if SDK >= 2.3, use documented API
			if (apiLevel >= 9) {
				intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
				Uri uri = Uri.fromParts(SCHEME, pkgName, null);
				intent.setData(uri);
			}

//			// if SDK < 2.1, use undocumented API (@see: source
//			// InstalledAppDetails)
//			else {
//				final String appPkgName = (apiLevel == 8 ? APP_PKG_NAME_22
//						: APP_PKG_NAME_21);
//				intent.setAction(Intent.ACTION_VIEW);
//				intent.setClassName(APP_DETAILS_PACKAGE_NAME,
//						APP_DETAILS_CLASS_NAME);
//				intent.putExtra(appPkgName, pkgName);
//			}

			startActivity(context, intent);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	public static boolean showAppDetailsForResult(Fragment fragment,
			String pkgName, int requestCode) {
		try {
			fragment.startActivityForResult(getAppinfoIntent(pkgName),
					requestCode);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return true;
	}

	public static boolean showAppDetailsForResult(Activity activity,
			String pkgName, int requestCode) {
		try {
			startActivityForResult(activity, getAppinfoIntent(pkgName),
					requestCode);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return true;
	}

	public static Intent getAppinfoIntent(String pkgName) {
		Intent intent = new Intent();
		final int apiLevel = Build.VERSION.SDK_INT;
		try {
			// if SDK >= 2.3, use documented API
			if (apiLevel >= 9) {
				intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
				Uri uri = Uri.fromParts(SCHEME, pkgName, null);
				intent.setData(uri);
			}
//
//			// if SDK < 2.1, use undocumented API (@see: source
//			// InstalledAppDetails)
//			else {
//				final String string = (apiLevel == 8 ? APP_PKG_NAME_22
//						: APP_PKG_NAME_21);
//				intent.setAction(Intent.ACTION_VIEW);
//				intent.setClassName(APP_DETAILS_PACKAGE_NAME,
//						APP_DETAILS_CLASS_NAME);
//				intent.putExtra(string, pkgName);
//			}
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return intent;
	}

	private static void startActivity(Context context, Intent intent) {
		try {
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	private static void startActivityForResult(Activity activity,
			Intent intent, int requestCode) {
		try {
			// intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			activity.startActivityForResult(intent, requestCode);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	private static void startActivityForResult(Fragment fragment,
			Intent intent, int requestCode) {
		try {
			// intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			fragment.startActivityForResult(intent, requestCode);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	private static final int INSTALL_LOCATION_AUTO = 0;
	private static final int INSTALL_LOCATION_INTERNALONLY = 1;
	private static final int INSTALL_LOCATION_PREFEREXTERNAL = 2;

	public static boolean isMoveable(Context context, String pkgName) {
		// ignore exception package name
		if ("com.wIRCTCMobiles".equals(pkgName)) {
			return false;
		}

		boolean isMoveable = false;
        int defaultInstallLocation = getDefaultInstallLocation();
        int installLocation = -100;

        try {
            installLocation = getInstallLocation(context.getPackageManager(), context.getPackageManager().getApplicationInfo(pkgName, 0));

            if (installLocation != -100) {
                if (installLocation == 1) {
                    isMoveable = false;
                } else if (installLocation != -1) {
                    isMoveable = true;
                } else if (defaultInstallLocation != -10) {
                    isMoveable = defaultInstallLocation == 2;
                }
                return isMoveable;
            }

        } catch (Exception e) {
        }

        try {
			AssetManager am = context.createPackageContext(pkgName, 0)
					.getAssets();
			XmlResourceParser xml = am
					.openXmlResourceParser("AndroidManifest.xml");
			int eventType = xml.getEventType();
			xmlloop: while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.START_TAG:
					if (!xml.getName().matches("manifest")) {
						break xmlloop;
					}

					else {
						attrloop: for (int j = 0; j < xml.getAttributeCount(); j++) {

							if (xml.getAttributeName(j).matches(
									"installLocation")) {
								String value = xml.getAttributeValue(j);
								if (isNumber(value)) {
									int location = Integer.parseInt(value);
                                    installLocation = location;
									switch (location) {
									case INSTALL_LOCATION_AUTO:
										isMoveable = true;
										break;
									case INSTALL_LOCATION_INTERNALONLY:
										isMoveable = false;
										break;
									case INSTALL_LOCATION_PREFEREXTERNAL:
										isMoveable = true;
										break;
									default:
										// Shouldn't happen
										isMoveable = false;
										break;
									}
								}
								break attrloop;
							}

						}
					}
					break;
				}
				eventType = xml.nextToken();
			}


        } catch (Exception e) {
            Log.w(TAG, e);
        }


        if (installLocation == -100 && defaultInstallLocation != -10) {
            isMoveable = defaultInstallLocation == 2;
        }

		return isMoveable;
	}

	private static boolean isNumber(String string) {
		Pattern pattern = Pattern.compile("[0-9]*");
		return pattern.matcher(string).matches();
	}

	public static final int PACKAGE_STATE_INVALID = -1;
	public static final int PACKAGE_STATE_NOT_INSTALL = 0;
	public static final int PACKAGE_STATE_NEED_UPGRADE = 1;
	public static final int PACKAGE_STATE_NEED_DOWNGRADE = 2;

	public int checkPkgState(Context context, String pkgName,
			int uninstalledVersion) {
		if (isNameEmpty(pkgName)) {
			return PACKAGE_STATE_INVALID;
		}

		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(pkgName,
					PackageManager.GET_ACTIVITIES);
			int installedVersion = pi.versionCode;
			if (uninstalledVersion - installedVersion > 0) {
				return PACKAGE_STATE_NEED_UPGRADE;
			} else {
				return PACKAGE_STATE_NEED_DOWNGRADE;
			}
		} catch (Exception e) {
			Log.w(TAG, e);
			return PACKAGE_STATE_NOT_INSTALL;
		}
	}

	public static void startUninstall(Context context, String pkgName) {
		try {
			Uri u = Uri.parse("package:" + pkgName);
			Intent i = new Intent(Intent.ACTION_DELETE, u);
			i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(i);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	public static void startInstall(Activity activity, String locator) {
		try {
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.parse("file://" + locator),
					"application/vnd.android.package-archive");
			startActivity(activity, intent);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	public static void startInstallForResult(Activity activity, String locator,
			int requestCode) {
		try {
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.parse("file://" + locator),
					"application/vnd.android.package-archive");
			startActivityForResult(activity, intent, requestCode);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	public static void startInstallForResult(Fragment fragment, String locator,
			int requestCode) {
		try {
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(Uri.parse("file://" + locator),
					"application/vnd.android.package-archive");
			startActivityForResult(fragment, intent, requestCode);
		} catch (Exception e) {
			Log.w(TAG, e);
		}
	}

	public static boolean switchApp(Context context, String pkgName) {
		try {
			if (!context.getPackageName().equals(pkgName)) {
				PackageManager pm = context.getPackageManager();
				Intent intent = pm.getLaunchIntentForPackage(pkgName);
				if (intent != null) {
					context.startActivity(intent);
					return true;
				}
			}
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return false;
	}

	public static boolean isOnSdCard(Context context, String pkgName) {
		boolean onSdcard = false;
		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(pkgName, 0);
			ApplicationInfo ai = pi.applicationInfo;
			String location = ai.sourceDir;
			if (location.contains("/mnt")) {
				onSdcard = true;
			}
		} catch (Exception e) {
			Log.w(TAG, e);
		}
		return onSdcard;
	}

//	public static Bitmap loadPluginIcon(Context context, String uri) {
//		if (FileUtil.exists(uri)) {
//			Drawable drawable = Drawable.createFromPath(uri);
//			if (drawable == null) {
//				drawable = ViewUtil.getDefaultIconDrawable();
//			}
//			return drawableToBitmap(context, drawable);
//		} else {
//			Drawable drawable = ViewUtil.getDefaultIconDrawable();
//			return drawableToBitmap(context, drawable);
//		}
//	}

//	public static String loadPkgName(Context context, String pkgName) {
//		try {
//			return loadAppInfo(context, pkgName).packageName;
//		} catch (Exception e) {
//			Log.w(TAG, e);
//			return "";
//		}
//	}

	public static Bitmap loadAppIcon(Context context, String pkgName) {
		ApplicationInfo ai = loadAppInfo(context, pkgName);
		if (ai != null) {
			Drawable drawable = ai.loadIcon(context.getPackageManager());
			Bitmap bitmap = drawableToBitmap(context, drawable);
			return bitmap;
		} else {
			Drawable drawable = context.getResources().getDrawable(
					android.R.drawable.ic_menu_help);
			Bitmap bitmap = drawableToBitmap(context, drawable);
			return bitmap;
		}
	}

	public static Bitmap drawableToBitmap(Context context, Drawable drawable) {
		if (drawable == null) {
			return null;
		}

		float density = context.getResources().getDisplayMetrics().density;
		int width = (int) (drawable.getIntrinsicWidth() * density);
		int height = (int) (drawable.getIntrinsicHeight() * density);
		Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Config.ARGB_8888
				: Config.RGB_565;
		Bitmap bitmap = Bitmap.createBitmap(width, height, config);
		Canvas canvas = new Canvas(bitmap);
		drawable.setBounds(0, 0, width, height);
		drawable.draw(canvas);
		return bitmap;
	}

	public static Drawable loadAppIcon(Context context, ApplicationInfo ai) {
		Drawable result = null;
		if (ai != null) {
			result = ai.loadIcon(context.getPackageManager());
		} else {
			result = context.getResources().getDrawable(
					android.R.drawable.ic_menu_help);
		}
		return result;
	}

	public static ApplicationInfo getAppInfo(Context context, String apkUri) {
		PackageInfo pi = loadApkInfo(context, apkUri);
		if (pi != null) {
			ApplicationInfo ai = pi.applicationInfo;
			if (Build.VERSION.SDK_INT >= 8) {
				ai.sourceDir = apkUri;
				ai.publicSourceDir = apkUri;
			}
			return ai;
		} else {
			return null;
		}
	}

	public static String loadAppName(Context context, String pkgName) {
		ApplicationInfo ai = loadAppInfo(context, pkgName);
		return loadAppName(context, ai);
	}

	public static String loadAppName(Context context, ApplicationInfo ai) {
		String result = "";
		try {
			result = ai.loadLabel(context.getPackageManager()).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static String getName(Context context, String uri) {
		try {
			ApplicationInfo ai = getAppInfo(context, uri);
			return context.getPackageManager().getApplicationLabel(ai)
					.toString();
		} catch (Exception e) {
			Log.w(TAG, e);
			return null;
		}
	}

	public static String getVersionName(Context context) {
		return getVersionName(context, context.getPackageName());
	}

	public static String getVersionName(Context context, String pkgName) {
		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(pkgName, 0);
			return pi.versionName;
		} catch (Exception e) {
			Log.w(TAG, e);
			return null;
		}
	}

	public static int getVersionCode(Context context) {
		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
			return pi.versionCode;
		} catch (Exception e) {
			Log.w(TAG, e);
			return -1;
		}
	}

	public static int getVersionCode(Context context, String pkgName) {
		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(pkgName, 0);
			return pi.versionCode;
		} catch (Exception e) {
			Log.w(TAG, e);
			return -1;
		}
	}

	public static boolean isSystemApp(Context context, String pkgName) {
		try {
			PackageManager pm = context.getPackageManager();
			ApplicationInfo ai = pm.getApplicationInfo(pkgName, 0);
			int f = ai.flags & ApplicationInfo.FLAG_SYSTEM;
			return f == ApplicationInfo.FLAG_SYSTEM;
		} catch (Exception e) {
			Log.w(TAG, e);
			return true;
		}
	}

	@SuppressLint("NewApi")
	public static boolean isFreezable(Context context, String pkgName) {
		boolean freezable = false;

		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(pkgName,
					PackageManager.GET_ACTIVITIES
							| PackageManager.GET_SIGNATURES);
			ApplicationInfo ai = pm.getApplicationInfo(pkgName, 0);
			PackageInfo sys = pm.getPackageInfo("android",
					PackageManager.GET_SIGNATURES);
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_HOME);
			intent.setPackage(ai.packageName);
			List<ResolveInfo> homes = pm.queryIntentActivities(intent, 0);
			if ((homes != null && homes.size() > 0)
					|| (pi != null && pi.signatures != null && sys.signatures[0]
							.equals(pi.signatures[0]))) {
				// Disable button for core system applications.
				freezable = false;
			} else if (ai.enabled) {
				freezable = true;
			} else {
				freezable = true;
			}

			if (Build.VERSION.SDK_INT >= 8) {
				DevicePolicyManager dpm = (DevicePolicyManager) context
						.getSystemService(Context.DEVICE_POLICY_SERVICE);
				List<ComponentName> admins = dpm.getActiveAdmins();
				for (int i = 0; admins != null && i < admins.size(); i++) {
					if (admins.get(i).getPackageName().equals(pi.packageName)) {
						freezable = false;
						break;
					}
				}
			}
		} catch (Exception e) {
			Log.w(TAG, e);
		}

		return freezable;
	}

	public static boolean isFreezed(Context context, String pkgName) {
		try {
			PackageManager pm = context.getPackageManager();
			ApplicationInfo ai = pm.getApplicationInfo(pkgName, 0);
			return !ai.enabled;
		} catch (Exception e) {
			Log.w(TAG, e);
			return false;
		}
	}

	@SuppressLint("NewApi")
	public static long getFirstInstallTime(Context context, String pkgName) {
		try {
			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(pkgName, 0);
			return pi.firstInstallTime;
		} catch (Exception e) {
			Log.w(TAG, e);
			return -1;
		}
	}

	public static long getInstallDays(Context context, String pkgName) {
		long first = getFirstInstallTime(context, pkgName);
		long delta = System.currentTimeMillis() - first;
		return delta / DAY;
	}

	public static String loadSourceDir(Context context, String pkgName) {
		try {
			return loadAppInfo(context, pkgName).sourceDir;
		} catch (Exception e) {
			Log.d(TAG, "retrieveSourceDir(): " + e.getMessage());
			return "";
		}
	}

	public static long loadPackageSize(Context context, String pkgName) {
		ApplicationInfo ai = loadAppInfo(context, pkgName);
		if (ai != null) {
			return new File(ai.sourceDir).length();
		} else {
			return -1;
		}
	}

//	public static Bitmap loadIcon(Context context, String pkgName,
//			String resName) {
//		try {
//			Drawable drawable1 = ThemeUtil.getDrawableByFileName(context,
//					pkgName, resName);
//			BitmapDrawable bd = (BitmapDrawable) drawable1;
//			Bitmap bm = bd.getBitmap();
//			return bm;
//		} catch (Exception e) {
//			return PackageUtil.loadAppIcon(context, pkgName);
//		}
//	}

    public static int getInstallLocation(PackageManager paramPackageManager, ApplicationInfo paramApplicationInfo) {
        try {
            x = ApplicationInfo.class.getField("installLocation");
            return getLocationValue(paramApplicationInfo);
        } catch (Exception localException2) {
            try {
                x = PackageInfo.class.getField("installLocation");
                return getLocationValue(paramPackageManager.getPackageInfo(paramApplicationInfo.packageName, 0));
            } catch (Exception localException3) {
            }
        }
        return -100;
    }

    private static int getLocationValue(Object paramObject) {
        try {
            int i1 = ((Integer) x.get(paramObject)).intValue();
            return i1;
        } catch (Exception localException) {
        }
        return -100;
    }


    public static int getDefaultInstallLocation() {
        int result = -10;
        try {

            //���ServiceManager��
            Class ServiceManager = Class
                    .forName("android.os.ServiceManager");

            //���ServiceManager��getService����
            Method getService = ServiceManager.getMethod("getService", String.class);

            //����getService��ȡRemoteService
            Object oRemoteService = getService.invoke(null, "package");

            //���IPackageManager.Stub��
            Class cStub = Class
                    .forName("android.content.pm.IPackageManager$Stub");
            //���asInterface����
            Method asInterface = cStub.getMethod("asInterface", android.os.IBinder.class);
            //����asInterface������ȡIPackageManage����
            Object oIPackageManage = asInterface.invoke(null, oRemoteService);
            //getInstallLocation()����
            Method getInstallLocation = oIPackageManage.getClass().getMethod("getInstallLocation");
            //getInstallLocation()����
            result = (int) getInstallLocation.invoke(oIPackageManage);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
}
