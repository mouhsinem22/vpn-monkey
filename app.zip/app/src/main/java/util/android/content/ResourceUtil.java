package util.android.content;

import android.content.Context;

/**
 * Created by Administrator
 * on 2018/6/28 0028.
 */

public class ResourceUtil {

    public static String getCountry(Context context) {
        String res = "";

        try {
            res = context.getResources().getConfiguration().locale.getCountry();
        } catch (Throwable ignored) {
        }

        return res;
    }

}
