package util.android.content;

import android.app.Activity;
import android.os.storage.StorageManager;


import java.util.Iterator;
import java.util.List;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

public class ContextUtil {
    private static final String TAG = ContextUtil.class.getSimpleName();

    /**
     * @param context
     * @param address
     * @param content
     */
    public static void sendSMS(Context context, String address, String content) {
        try {
            Intent i = new Intent(Intent.ACTION_SENDTO);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.putExtra("sms_body", content + " " + address);
            i.setType("vnd.android-dir/mms-sms");
            i.setData(Uri.parse("smsto:" + address));
            context.startActivity(i);
        } catch (Exception e) {
            Log.w(TAG, e);
        }
    }

    /**
     * @param context
     * @param address
     * @param title
     * @param content
     */
    public static void sendEmail(Context context, String address, String title,
                                 String content) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.setType("plain/text");
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{address});
            i.putExtra(Intent.EXTRA_SUBJECT, title);
            i.putExtra(Intent.EXTRA_TEXT, content);
            context.startActivity(i);
        } catch (Exception e) {
            Log.w(TAG, e);
        }
    }

    /**
     * @param context
     * @param pkgName
     */
    public static void openInGooglePlay(Context context, String pkgName) {
        openUrlInGP(context, "https://play.google.com/store/apps/details?id="
                + pkgName);
    }

    /**
     * @param context
     * @param resId
     */
    public static void openUrl(Context context, int resId) {
        openUrl(context, context.getString(resId));
    }

    /**
     * @param context
     * @param url
     */
    public static void openUrl(Context context, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.setData(Uri.parse(url));
            context.startActivity(i);
        } catch (Exception e) {
            Log.w(TAG, e);
        }
    }

    /**
     * Start activity ignoring exceptions
     *
     * @param context
     * @param clazz
     */
    public static void startActivity(Context context, Class clazz) {
        startActivity(context, clazz, Intent.FLAG_ACTIVITY_NEW_TASK, null);
    }

    /**
     * Start activity ignoring exceptions
     *
     * @param context
     * @param clazz
     */
    public static void startActivity(Context context, Class clazz, Bundle bundle) {
        startActivity(context, clazz, Intent.FLAG_ACTIVITY_NEW_TASK, bundle);
    }

    /**
     * Start activity ignoring exceptions
     *
     * @param context
     * @param clazz
     * @param flags
     */
    public static void startActivity(Context context, Class clazz, int flags) {
        startActivity(context, clazz, flags, null);
    }

    /**
     * Start activity ignoring exceptions
     *
     * @param context
     * @param clazz
     * @param flags
     */
    public static void startActivity(Context context, Class clazz, int flags, Bundle bundle) {
        try {
            Intent i = new Intent(context, clazz);
            if (flags != -1) {
                i.setFlags(flags);
            }
            if (bundle != null) {
                i.putExtras(bundle);
            }
            startActivity(context, i);
        } catch (Exception e) {
            Log.w(TAG, e);
        }
    }

    public static void startActivity(Context context, Intent intent) {
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            Log.w(TAG, e);
        }
    }

    /**
     * Start activity ignoring exceptions
     */
    public static void startActivityForResult(Activity activity, Class clazz,
                                              int requestCode) {
        startActivityForResult(activity, clazz, Intent.FLAG_ACTIVITY_NEW_TASK,
                requestCode, null);
    }

    /**
     * Start activity ignoring exceptions
     */
    @SuppressLint("NewApi")
    public static void startActivityForResult(Activity activity, Class clazz,
                                              int flags, int requestCode, Bundle options) {
        try {
            Intent i = new Intent(activity, clazz);
            i.setFlags(flags);
            activity.startActivityForResult(i, requestCode, options);
        } catch (Exception e) {
            Log.w(TAG, e);
        }
    }

    /**
     * @return ActivityManager
     */
    public static ActivityManager getAM(Context context) {
        if (context != null) {
            return (ActivityManager) context
                    .getSystemService(Context.ACTIVITY_SERVICE);
        } else {
            return null;
        }
    }

    /**
     * @return PackageManager
     */
    public static PackageManager getPM(Context context) {
        if (context != null) {
            return context.getPackageManager();
        } else {
            return null;
        }
    }

    /**
     * @return StorageManager
     */
    public static StorageManager getSM(Context context) {
        if (context != null) {
            return (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
        } else {
            return null;
        }
    }

    public static final String PLAY_GOOGLE_COM = "play.google.com";
    public static final String MARKET_ANDROID_COM = "market.android.com";
    public static final String MARKET = "market";
    public static final String GOOGLE_PLAY_PACKAGENAME = "com.android.vending";

    public static boolean isAppStoreUrl(final String url) {
        if (url == null) {
            return false;
        }

        final Uri uri = Uri.parse(url);
        final String scheme = uri.getScheme();
        final String host = uri.getHost();

        if (PLAY_GOOGLE_COM.equals(host) || MARKET_ANDROID_COM.equals(host)) {
            return true;
        }

        if (MARKET.equals(scheme)) {
            return true;
        }

        return false;
    }

    // Copy of package com.yeahmobi.android.common.util;
    @TargetApi(Build.VERSION_CODES.ECLAIR)
    public static boolean openUrlInGP(Context mContext, String targetUrl) {
        boolean result = false;
        if (isAppStoreUrl(targetUrl)) {

            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse(targetUrl));
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);

            try {
                Iterator<ResolveInfo> resolveInfos = mContext
                        .getPackageManager()
                        .queryIntentActivities(browserIntent,
                                Intent.FLAG_ACTIVITY_NO_ANIMATION).iterator();
                while (resolveInfos.hasNext()) {
                    ResolveInfo ri = resolveInfos.next();
                    if (ri.activityInfo.packageName
                            .equals(GOOGLE_PLAY_PACKAGENAME)) {
                        browserIntent.setClassName(ri.activityInfo.packageName,
                                ri.activityInfo.name);
                        mContext.startActivity(browserIntent);
                        result = true;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return result;
    }

    public static void openUrlStrategy(Context context, String targetUrl) {
//		try {
//			if (!openUrlInGP(context, targetUrl)) {
//				AWebView.loadUrl(context, context.getString(R.string.all_in_one_toolbox), targetUrl);
//			}
//		} catch(Throwable t) {
//			t.printStackTrace();
//		}
    }

    // Copy of package com.yeahmobi.android.common.util;
    @TargetApi(Build.VERSION_CODES.ECLAIR)
    public static boolean openUrlWithApp(Context context, String pkgName, String targetUrl) {
        boolean result = false;

        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl));
        browserIntent.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        browserIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        browserIntent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);

        try {
            PackageManager pm = context.getPackageManager();
            List<ResolveInfo> list = pm.queryIntentActivities(browserIntent, Intent.FLAG_ACTIVITY_NO_ANIMATION);
            Iterator<ResolveInfo> it = list.iterator();
            while (it.hasNext()) {
                ResolveInfo ri = it.next();
                if (ri.activityInfo.packageName.equals(pkgName)) {
                    browserIntent.setClassName(ri.activityInfo.packageName, ri.activityInfo.name);
                    context.startActivity(browserIntent);
                    result = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    public static void sendFeedback(Context context, String email) {
        ContextUtil.sendEmail(
                context,
                email,
                "Feedback",
                buildDebugInfo(context));
    }

    public static String buildDebugInfo(Context context) {
        return "\n\n----------------------------------------------------------\n"
                + "Manufacturer: "  + Build.MANUFACTURER + "\n"
                + "Model: " + Build.MODEL + "\n"
                + "OS Version: " + Build.VERSION.RELEASE + "\n"
                + "ROM: " + Build.DISPLAY + "\n"
                + "Country: " + ResourceUtil.getCountry(context) + "\n"
                + "Package Name: " + context.getPackageName() + "\n"
                + "Version Name: " + PackageUtil.getVersionName(context) + "(" + PackageUtil.getVersionCode(context) + ")" + "\n"
                + "\n----------------------------------------------------------\n\n";
    }
}
